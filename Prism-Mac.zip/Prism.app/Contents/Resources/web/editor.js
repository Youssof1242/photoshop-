/* Prism — offline, layer-based canvas editor. No external dependencies. */
(() => {
  'use strict';
  const clamp = (v, a, b) => Math.min(b, Math.max(a, Number(v) || 0));
  const makeCanvas = (w, h) => { const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(h)); return c; };
  const cloneCanvas = c => { const copy = makeCanvas(c.width, c.height); copy.getContext('2d').drawImage(c, 0, 0); return copy; };
  const readImage = src => new Promise((resolve, reject) => { const img = new Image(); img.onload = () => resolve(img); img.onerror = () => reject(new Error('This image could not be opened. Please choose a PNG, JPEG, WebP, or GIF image.')); img.src = src; });
  const uid = () => `layer-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  const validColor = color => { const ctx = makeCanvas(1,1).getContext('2d'); ctx.fillStyle = '#000000'; try { ctx.fillStyle = color; } catch (_) {} return ctx.fillStyle; };
  const colorRGBA = color => { const c = makeCanvas(1,1), x = c.getContext('2d'); x.fillStyle = color; x.fillRect(0,0,1,1); return x.getImageData(0,0,1,1).data; };
  const BLENDS = new Set(['normal','source-over','multiply','screen','overlay','darken','lighten','color-dodge','color-burn','hard-light','soft-light','difference','exclusion','hue','saturation','color','luminosity']);
  const MAX_DOCUMENT_PIXELS = 32000000, MAX_LAYER_PIXELS = 64000000, MAX_LAYERS = 50;
  const assertSize = (w,h,count=1) => {
    if (!Number.isFinite(w) || !Number.isFinite(h) || !Number.isInteger(w) || !Number.isInteger(h) || w<1 || h<1 || w>8192 || h>8192 || w*h>MAX_DOCUMENT_PIXELS) throw new Error('Images must be 1–8192 pixels per side and no more than 32 megapixels.');
    if (count>MAX_LAYERS || w*h*count>MAX_LAYER_PIXELS) throw new Error('This document would exceed the layer memory limit. Merge layers or choose a smaller image.');
  };
  const assertDataURL = (src, project=false) => {
    const pattern = project ? /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=\s]+$/ : /^data:image\/(png|jpeg|jpg|webp|gif|bmp);base64,[A-Za-z0-9+/=\s]+$/;
    if (typeof src!=='string' || src.length>180000000 || !pattern.test(src)) throw new Error('Choose a supported local image. External image URLs are not supported.');
    // Check common headers before asking the browser to decode a compressed image.
    let head;try{const fragment=src.slice(src.indexOf(',')+1,src.indexOf(',')+1+4096).replace(/\s/g,'');head=atob(fragment.slice(0,fragment.length-fragment.length%4));}catch(_){throw new Error('The image data is damaged.');}
    const n=i=>head.charCodeAt(i),be32=i=>(n(i)*16777216+n(i+1)*65536+n(i+2)*256+n(i+3)),le24=i=>n(i)+n(i+1)*256+n(i+2)*65536;
    const mime=src.slice(11,src.indexOf(';'));let w,h,signature=false;
    if(mime==='png'){signature=head.slice(0,8)==='\x89PNG\r\n\x1a\n';if(signature){w=be32(16);h=be32(20);}}
    else if(mime==='jpeg'||mime==='jpg'){signature=n(0)===255&&n(1)===216;}
    else if(mime==='webp'){signature=head.slice(0,4)==='RIFF'&&head.slice(8,12)==='WEBP';if(signature&&head.slice(12,16)==='VP8X'){w=le24(24)+1;h=le24(27)+1;}else if(signature&&head.slice(12,16)==='VP8L'){w=1+((n(21)|(n(22)<<8))&16383);h=1+(((n(22)>>6)|(n(23)<<2)|(n(24)<<10))&16383);}else if(signature&&head.slice(12,16)==='VP8 '){w=(n(26)|(n(27)<<8))&16383;h=(n(28)|(n(29)<<8))&16383;}}
    else if(mime==='gif'){signature=head.slice(0,3)==='GIF';if(signature){w=n(6)+n(7)*256;h=n(8)+n(9)*256;}}
    else if(mime==='bmp'){signature=head.slice(0,2)==='BM';}
    if(!signature)throw new Error('The image type does not match its contents.');
    if(w!==undefined)assertSize(w,h);
  };

  class PrismEditor {
    constructor(canvas, wrapper) {
      if (!canvas || !wrapper) throw new Error('PrismEditor requires a canvas and workspace element.');
      this.canvas = canvas; this.wrapper = wrapper; this.ctx = canvas.getContext('2d');
      this.overlay = document.createElement('canvas'); this.overlay.className = 'editor-overlay';
      Object.assign(this.overlay.style, { position:'absolute', pointerEvents:'none', zIndex:'2' }); wrapper.appendChild(this.overlay);
      Object.assign(canvas.style, { position:'absolute', zIndex:'1', display:'block', touchAction:'none', boxShadow:'0 12px 60px #0008', backgroundColor:'#fff', backgroundImage:'linear-gradient(45deg,#dedede 25%,transparent 25%),linear-gradient(-45deg,#dedede 25%,transparent 25%),linear-gradient(45deg,transparent 75%,#dedede 75%),linear-gradient(-45deg,transparent 75%,#dedede 75%)', backgroundSize:'16px 16px', backgroundPosition:'0 0,0 8px,8px -8px,-8px 0' });
      if (getComputedStyle(wrapper).position === 'static') wrapper.style.position = 'relative';
      wrapper.style.overflow = 'hidden'; wrapper.style.touchAction = 'none';
      this.events = {}; this.layers = []; this.width = 1400; this.height = 980; this.name = 'Alpine reverie';
      this.tool = 'move'; this.color = '#202b36'; this.secondaryColor = '#ffffff'; this.brushSize = 32; this.brushOpacity = 1; this.brushHardness = .85;
      this.zoom = .5; this.panX = 0; this.panY = 0; this.selection = null; this.pointer = null; this.spaceDown = false;
      this.history = []; this.historyIndex = -1; this.historyLimit = 25; this.historyByteLimit = 80 * 1024 * 1024; this.dirty = false; this.busy = false;
      this._bind(); this._makeDemo(); this._commit('Original artwork', false); this.fitToView();
      this._observer = new ResizeObserver(() => { this._syncLayout(); this._emit('change', this.getState()); }); this._observer.observe(wrapper);
      requestAnimationFrame(() => this._emit('change', this.getState()));
    }
    on(name, fn) { (this.events[name] ||= []).push(fn); return () => { this.events[name] = (this.events[name] || []).filter(f => f !== fn); }; }
    _emit(name, value) { for (const fn of this.events[name] || []) { try { fn(value); } catch (error) { console.error(error); } } }
    _changed() { this._emit('change', this.getState()); }
    _error(error) { this._emit('error', error instanceof Error ? error.message : String(error)); }
    getState() {
      return { width:this.width, height:this.height, name:this.name, layers:this.layers.map(l => ({ id:l.id, name:l.name, visible:l.visible, locked:l.locked, opacity:l.opacity, blendMode:l.blendMode, x:l.x, y:l.y, thumbnail:this._thumbnail(l) })), selectedLayerId:this.selectedLayerId, tool:this.tool, color:this.color, secondaryColor:this.secondaryColor, brushSize:this.brushSize, brushOpacity:this.brushOpacity, brushHardness:this.brushHardness, zoom:this.zoom, dirty:this.dirty, selection:this.selection ? {...this.selection} : null, history:this.history.map(h => ({name:h.name})), historyIndex:this.historyIndex, busy:this.busy };
    }
    _thumbnail(layer) {
      if (layer.thumbnail) return layer.thumbnail;
      const c = makeCanvas(96, 68), ctx = c.getContext('2d'), scale = Math.min(96/this.width, 68/this.height), w = this.width*scale, h = this.height*scale;
      ctx.drawImage(layer.canvas, (96-w)/2+layer.x*scale, (68-h)/2+layer.y*scale, w, h);
      return layer.thumbnail = c.toDataURL('image/png');
    }
    _layer(name, canvas) { return { id:uid(), name:name || `Layer ${this.layers.length+1}`, canvas:canvas || makeCanvas(this.width, this.height), visible:true, locked:false, opacity:1, blendMode:'normal', x:0, y:0, thumbnail:null }; }
    _selected() { return this.layers.find(l => l.id === this.selectedLayerId); }
    _reserveLayer(extra=1) { assertSize(this.width,this.height,this.layers.length+extra); }
    _finishGesture() { if(this.pointer)this._pointerUp({pointerId:this.pointer.id}); }
    _paintable() { const l = this._selected(); if (!l || l.locked) { this._emit('notice', 'Select an unlocked layer to edit.'); return null; } return l; }
    _invalidate(layer) { if (layer) layer.thumbnail = null; }
    _snapshot() {
      return { width:this.width, height:this.height, name:this.name, selectedLayerId:this.selectedLayerId, layers:this.layers.map(l => ({ id:l.id, name:l.name, visible:l.visible, locked:l.locked, opacity:l.opacity, blendMode:l.blendMode, x:l.x, y:l.y, data:l.canvas.toDataURL('image/png') })) };
    }
    _commit(name, dirty = true) {
      this.history.splice(this.historyIndex+1);
      const snapshot = this._snapshot();
      this.history.push({ name, snapshot, bytes:snapshot.layers.reduce((n,l) => n+l.data.length*2, 0) });
      let total = this.history.reduce((n,h) => n+h.bytes,0);
      while (this.history.length > 2 && (this.history.length > this.historyLimit || total > this.historyByteLimit)) total -= this.history.shift().bytes;
      this.historyIndex = this.history.length-1; if (dirty) this.dirty = true;
      this.render(); this._changed();
    }
    async _restore(snapshot) {
      const layers = await Promise.all(snapshot.layers.map(async data => {
        const img = await readImage(data.data); assertSize(img.width,img.height); const c = makeCanvas(snapshot.width, snapshot.height); c.getContext('2d').drawImage(img,0,0);
        return { id:String(data.id || uid()), name:String(data.name || 'Layer'), visible:data.visible!==false, locked:!!data.locked, opacity:clamp(data.opacity??1,0,1), blendMode:BLENDS.has(data.blendMode)?data.blendMode:'normal', canvas:c, thumbnail:null, x:clamp(data.x,-8192,8192), y:clamp(data.y,-8192,8192) };
      }));
      this.width = snapshot.width; this.height = snapshot.height; this.name = snapshot.name; this.layers = layers;
      this.selectedLayerId = layers.some(l => l.id === snapshot.selectedLayerId) ? snapshot.selectedLayerId : layers[layers.length-1]?.id;
      this.selection = null; this._syncLayout(); this.render();
    }
    async undo() {
      if(!this.busy)this._finishGesture();
      if (this.busy || this.historyIndex <= 0) return;
      this.busy = true; this._changed();
      try { await this._restore(this.history[this.historyIndex-1].snapshot); this.historyIndex--; this.dirty = true; }
      catch(error) { this._error(error); } finally { this.busy = false; this._changed(); }
    }
    async redo() {
      if(!this.busy)this._finishGesture();
      if (this.busy || this.historyIndex >= this.history.length-1) return;
      this.busy = true; this._changed();
      try { await this._restore(this.history[this.historyIndex+1].snapshot); this.historyIndex++; this.dirty = true; }
      catch(error) { this._error(error); } finally { this.busy = false; this._changed(); }
    }
    async goToHistory(index) {
      if(!this.busy)this._finishGesture();
      if (this.busy || index < 0 || index >= this.history.length || index === this.historyIndex) return;
      this.busy = true; this._changed();
      try { await this._restore(this.history[index].snapshot); this.historyIndex = index; this.dirty = true; }
      finally { this.busy = false; this._changed(); }
    }
    newDocument(w = 1600, h = 1000, name = 'Untitled') {
      w=Math.round(Number(w));h=Math.round(Number(h));assertSize(w,h);
      this.width = w; this.height = h; this.name = String(name || 'Untitled');
      this.layers = [this._layer('Background')]; const ctx = this.layers[0].canvas.getContext('2d'); ctx.fillStyle = '#ffffff'; ctx.fillRect(0,0,this.width,this.height);
      this.selectedLayerId = this.layers[0].id; this.selection = null; this.history = []; this.historyIndex = -1; this.dirty = false;
      this.fitToView(); this._commit('New document', false);
    }
    async loadImage(dataURL, name = 'Untitled image') {
      if(this.busy) throw new Error('Please wait for the current operation to finish.');
      assertDataURL(dataURL);this._finishGesture();this.busy=true;this._changed();
      try {
      const img = await readImage(dataURL); assertSize(img.width,img.height);
      this.width = img.width; this.height = img.height; this.name = String(name).replace(/\.[^.]+$/, '') || 'Untitled image';
      const l = this._layer('Background'); l.canvas.getContext('2d').drawImage(img,0,0); this.layers = [l]; this.selectedLayerId = l.id;
      this.history = []; this.historyIndex = -1; this.selection = null; this.dirty = false; this.fitToView(); this._commit('Open image', false);
      } finally {this.busy=false;this._changed();}
    }
    async addImage(dataURL, name = 'Placed image') {
      if(this.busy) throw new Error('Please wait for the current operation to finish.');
      assertDataURL(dataURL);this._finishGesture();this._reserveLayer();this.busy=true;this._changed();
      try {
      const img = await readImage(dataURL);assertSize(img.width,img.height);const l = this._layer(String(name).replace(/\.[^.]+$/, ''));
      const scale = Math.min(1, this.width/img.width, this.height/img.height), w = Math.round(img.width*scale), h = Math.round(img.height*scale);
      l.canvas.getContext('2d').drawImage(img, (this.width-w)/2, (this.height-h)/2, w, h);
      this.layers.push(l); this.selectedLayerId = l.id; this._commit('Place image');
      } finally {this.busy=false;this._changed();}
    }
    serializeProject() { if(this.busy) throw new Error('Please wait for the current operation to finish.');this._finishGesture(); return JSON.stringify({ format:'prism-project', version:1, ...this._snapshot() }); }
    async loadProject(json) {
      if(this.busy) throw new Error('Please wait for the current operation to finish.');
      let data; try { data = typeof json === 'string' ? JSON.parse(json) : json; } catch (_) { throw new Error('This project file is not valid JSON.'); }
      if (!data || data.format !== 'prism-project' || !Array.isArray(data.layers) || !data.layers.length || data.layers.some(l=>!l||typeof l!=='object')) throw new Error('This is not a supported Prism project.');
      assertSize(data.width,data.height,data.layers.length);
      for (const l of data.layers) assertDataURL(l.data,true);
      const clean={width:data.width,height:data.height,name:String(data.name||'Untitled'),selectedLayerId:String(data.selectedLayerId||''),layers:data.layers.map(l=>({id:uid(),name:String(l.name||'Layer').slice(0,200),visible:l.visible!==false,locked:!!l.locked,opacity:clamp(l.opacity??1,0,1),blendMode:BLENDS.has(l.blendMode)?l.blendMode:'normal',x:clamp(l.x,-8192,8192),y:clamp(l.y,-8192,8192),data:l.data}))};
      const selectedIndex=data.layers.findIndex(l=>String(l.id)===clean.selectedLayerId);clean.selectedLayerId=clean.layers[Math.max(0,selectedIndex)].id;
      this._finishGesture();this.busy=true;this._changed();
      try {await this._restore(clean);this.history=[];this.historyIndex=-1;this.dirty=false;this.fitToView();this._commit('Open project',false);}
      finally {this.busy=false;this._changed();}
    }
    markSaved() { this.dirty = false; this._changed(); }
    _composite(target, onlyLayers = this.layers, background) {
      const ctx = target.getContext('2d'); ctx.save(); ctx.setTransform(1,0,0,1,0,0); ctx.clearRect(0,0,target.width,target.height);
      if (background) { ctx.fillStyle = background; ctx.fillRect(0,0,target.width,target.height); }
      for (const layer of onlyLayers) { if (!layer.visible) continue; ctx.globalAlpha = layer.opacity; ctx.globalCompositeOperation = layer.blendMode === 'normal' ? 'source-over' : layer.blendMode; ctx.drawImage(layer.canvas,layer.x,layer.y); }
      ctx.restore();
    }
    exportImage(type = 'png', quality = .92) {
      const mime = type.includes('/') ? type : `image/${type === 'jpg' ? 'jpeg' : type}`; const c = makeCanvas(this.width,this.height);
      this._composite(c,this.layers,mime === 'image/jpeg' ? '#ffffff' : undefined); return c.toDataURL(mime, clamp(quality,0,1));
    }
    render() { if (this.canvas.width !== this.width || this.canvas.height !== this.height) { this.canvas.width = this.width; this.canvas.height = this.height; } this._composite(this.canvas); this._drawOverlay(); }
    _syncLayout() {
      const width = `${this.width*this.zoom}px`, height = `${this.height*this.zoom}px`, transform = `translate(calc(-50% + ${this.panX}px),calc(-50% + ${this.panY}px))`;
      for (const c of [this.canvas,this.overlay]) Object.assign(c.style, { width, height, left:'50%', top:'50%', transform, transformOrigin:'center' });
      if (this.overlay.width !== this.width || this.overlay.height !== this.height) { this.overlay.width = this.width; this.overlay.height = this.height; }
      this._drawOverlay(); this._cursor();
    }
    setZoom(value, anchor) {
      const next = clamp(value,.03,8), old = this.zoom;
      if (anchor) { const r = this.wrapper.getBoundingClientRect(); const x = anchor.x-r.left-r.width/2, y = anchor.y-r.top-r.height/2; this.panX = x-(x-this.panX)*(next/old); this.panY = y-(y-this.panY)*(next/old); }
      else { this.panX *= next/old; this.panY *= next/old; }
      this.zoom = next; this._syncLayout(); this._changed();
    }
    fitToView() { const r = this.wrapper.getBoundingClientRect(); this.zoom = clamp(Math.min((r.width-100)/this.width,(r.height-100)/this.height,1),.03,8); this.panX = 0; this.panY = 0; this._syncLayout(); this.render(); this._changed(); }
    setTool(tool) { const aliases = {rect:'rectangle', bucket:'fill', selection:'marquee', pencil:'brush', gradient:'fill'}; this.tool = aliases[tool] || tool; this._cursor(); this._drawOverlay(); this._changed(); }
    setColor(color) { this.color = validColor(color); this._changed(); }
    setSecondaryColor(color) { this.secondaryColor = validColor(color); this._changed(); }
    setBrushSize(value) { this.brushSize = clamp(value,1,1200); this._changed(); }
    setBrushOpacity(value) { this.brushOpacity = clamp(value,0,1); this._changed(); }
    setBrushHardness(value) { this.brushHardness = clamp(value,0,1); this._changed(); }
    _cursor() {
      const cursors = {move:'move',hand:this.pointer ? 'grabbing':'grab',zoom:'zoom-in',eyedropper:'crosshair',text:'text',crop:'crosshair',marquee:'crosshair',rectangle:'crosshair',ellipse:'crosshair',fill:'crosshair',brush:'crosshair',eraser:'crosshair'};
      this.wrapper.style.cursor = this.spaceDown ? (this.pointer ? 'grabbing' : 'grab') : (cursors[this.tool] || 'default'); this.canvas.style.cursor = 'inherit';
    }
    addLayer(name) { this._reserveLayer();const l = this._layer(name); const index = this.layers.findIndex(x => x.id === this.selectedLayerId); this.layers.splice(index+1,0,l); this.selectedLayerId = l.id; this._commit('New layer'); return l.id; }
    duplicateLayer() { const src = this._selected(); if (!src) return;this._reserveLayer();const l = {...src,id:uid(),name:`${src.name} copy`,canvas:cloneCanvas(src.canvas),thumbnail:null}; this.layers.splice(this.layers.indexOf(src)+1,0,l); this.selectedLayerId = l.id; this._commit('Duplicate layer'); }
    deleteLayer() { const l = this._selected(); if (!l || l.locked) return; const index = this.layers.indexOf(l); this.layers.splice(index,1); if (!this.layers.length) this.layers.push(this._layer('Layer 1')); this.selectedLayerId = this.layers[Math.min(index,this.layers.length-1)].id; this._commit('Delete layer'); }
    selectLayer(id) { if (this.layers.some(l => l.id === id)) { this.selectedLayerId = id; this._changed(); } }
    updateLayer(id, props) {
      const l = this.layers.find(x => x.id === id); if (!l) return;
      const allowed = {}; if ('name' in props) allowed.name = String(props.name).trim() || 'Layer'; if ('visible' in props) allowed.visible = !!props.visible; if ('locked' in props) allowed.locked = !!props.locked; if ('opacity' in props) allowed.opacity = clamp(props.opacity,0,1); if ('blendMode' in props && BLENDS.has(props.blendMode)) allowed.blendMode = props.blendMode;
      if (Object.keys(allowed).every(k => l[k] === allowed[k])) return;
      Object.assign(l,allowed); this._commit('Layer properties');
    }
    reorderLayer(id, targetIndex) { const index = this.layers.findIndex(l => l.id === id); if (index < 0) return; targetIndex = Math.round(clamp(targetIndex,0,this.layers.length-1)); if (index === targetIndex) return; const [l] = this.layers.splice(index,1); this.layers.splice(targetIndex,0,l); this._commit('Reorder layers'); }
    mergeDown() {
      const index = this.layers.findIndex(l => l.id === this.selectedLayerId); if (index < 1) return; const top = this.layers[index], bottom = this.layers[index-1]; if (top.locked || bottom.locked) return;
      const canvas = makeCanvas(this.width,this.height); this._composite(canvas,[bottom,top]);
      const l = this._layer(bottom.name,canvas); this.layers.splice(index-1,2,l); this.selectedLayerId = l.id; this._commit('Merge layers');
    }
    flatten() { const c = makeCanvas(this.width,this.height); this._composite(c); const l = this._layer('Flattened image',c); this.layers = [l]; this.selectedLayerId = l.id; this._commit('Flatten image'); }
    clearSelection() { this.selection = null; this._drawOverlay(); this._changed(); }
    selectAll() { this.selection = {x:0,y:0,w:this.width,h:this.height}; this._drawOverlay(); this._changed(); }
    deleteSelected() {
      const l = this._paintable(); if (!l) return; const c = l.canvas.getContext('2d'); if (this.selection) { const r = this.selection; c.clearRect(r.x-l.x,r.y-l.y,r.w,r.h); } else c.clearRect(0,0,this.width,this.height);
      this._invalidate(l); this._commit(this.selection ? 'Clear selection' : 'Clear layer');
    }
    _clipSelection(ctx, layer) { if (this.selection) { ctx.beginPath(); ctx.rect(this.selection.x-layer.x,this.selection.y-layer.y,this.selection.w,this.selection.h); ctx.clip(); } }
    resizeDocument(w,h) {
      w=Math.round(Number(w));h=Math.round(Number(h));assertSize(w,h,this.layers.length);const sx = w/this.width, sy = h/this.height;
      for (const l of this.layers) { const c = makeCanvas(w,h), x = c.getContext('2d'); x.imageSmoothingQuality = 'high'; x.drawImage(l.canvas,l.x*sx,l.y*sy,w,h); l.canvas = c; l.x = 0; l.y = 0; this._invalidate(l); }
      this.width = w; this.height = h; this.selection = null; this.fitToView(); this._commit('Image size');
    }
    _crop(rect) {
      const x = Math.max(0,Math.round(rect.x)), y = Math.max(0,Math.round(rect.y)), w = Math.min(this.width-x,Math.round(rect.w)), h = Math.min(this.height-y,Math.round(rect.h)); if (w < 2 || h < 2) return;
      for (const l of this.layers) { const c = makeCanvas(w,h); c.getContext('2d').drawImage(l.canvas,l.x-x,l.y-y); l.canvas = c; l.x = 0; l.y = 0; this._invalidate(l); }
      this.width = w; this.height = h; this.selection = null; this.fitToView(); this._commit('Crop image');
    }
    rotateDocument(degrees = 90) {
      const a = (Number(degrees)||90)*Math.PI/180, cos = Math.abs(Math.cos(a)), sin = Math.abs(Math.sin(a)), w = Math.round(this.width*cos+this.height*sin), h = Math.round(this.width*sin+this.height*cos);
      assertSize(w,h,this.layers.length);
      for (const l of this.layers) { const c = makeCanvas(w,h), ctx = c.getContext('2d'); ctx.translate(w/2,h/2); ctx.rotate(a); ctx.drawImage(l.canvas,l.x-this.width/2,l.y-this.height/2); l.canvas = c; l.x = 0; l.y = 0; this._invalidate(l); }
      this.width = w; this.height = h; this.selection = null; this.fitToView(); this._commit('Rotate image');
    }
    flipDocument(axis = 'horizontal') {
      for (const l of this.layers) { const c = makeCanvas(this.width,this.height), ctx = c.getContext('2d'); const horizontal = axis === 'horizontal' || axis === 'x'; ctx.translate(horizontal ? this.width : 0,horizontal ? 0 : this.height); ctx.scale(horizontal ? -1 : 1,horizontal ? 1 : -1); ctx.drawImage(l.canvas,l.x,l.y); l.canvas = c; l.x = 0; l.y = 0; this._invalidate(l); }
      this.selection = null; this._commit('Flip image');
    }
    addText(text, opts = {}) {
      if (!String(text).trim()) return;
      this._reserveLayer();
      const l = this._layer(opts.name || String(text).slice(0,30)), ctx = l.canvas.getContext('2d'), size = clamp(opts.size || opts.fontSize || 96,6,1200);
      ctx.font = `${opts.fontWeight || 500} ${size}px ${opts.fontFamily || 'Helvetica Neue, Arial, sans-serif'}`; ctx.fillStyle = validColor(opts.color || this.color); ctx.textBaseline = 'top'; ctx.globalAlpha = this.brushOpacity;
      const x = Number.isFinite(opts.x) ? opts.x : this.width*.1, y = Number.isFinite(opts.y) ? opts.y : this.height*.15;
      String(text).split('\n').forEach((line,i) => ctx.fillText(line,x,y+i*size*1.2)); this.layers.push(l); this.selectedLayerId = l.id; this._commit('Add text');
    }
    applyFilter(name, value) {
      const layer = this._paintable(); if (!layer) return;
      name = String(name).toLowerCase().replace(/\s+/g,'');
      const allowed = new Set(['brightness','contrast','saturation','hue','blur','grayscale','sepia','invert','sharpen','warmth']);
      if (!allowed.has(name)) return;
      const src = layer.canvas, result = cloneCanvas(src), ctx = result.getContext('2d', {willReadFrequently:true});
      const img = ctx.getImageData(0,0,this.width,this.height), p = img.data;
      if (name === 'blur') {
        const radius = Math.round(clamp(value ?? 4,0,40)); if (!radius) return;
        // Three separable box passes give a soft Gaussian-like blur in every WebKit version.
        let pixels = p; const r = Math.max(1,Math.round(radius*.6));
        for (let pass=0;pass<3;pass++) pixels = this._boxBlur(pixels,this.width,this.height,r);
        p.set(pixels);
      } else if (name === 'sharpen') {
        const amount = clamp(value ?? 1,0,3), original = new Uint8ClampedArray(p), w = this.width, h = this.height;
        for (let y=1;y<h-1;y++) for (let x=1;x<w-1;x++) { const i=(y*w+x)*4; for (let k=0;k<3;k++) p[i+k] = original[i+k]*(1+4*amount)-amount*(original[i-4+k]+original[i+4+k]+original[i-w*4+k]+original[i+w*4+k]); }
      } else {
        const v = Number.isFinite(Number(value)) ? Number(value) : (['grayscale','sepia','invert'].includes(name) ? 1 : 0);
        const brightness = clamp(v,-100,100)*2.55, contrast = (259*(clamp(v,-100,100)*2.55+255))/(255*(259-clamp(v,-100,100)*2.55));
        const saturation = 1+clamp(v,-100,100)/100, amount = clamp(v,0,1), angle = clamp(v,-180,180)*Math.PI/180, co = Math.cos(angle), si = Math.sin(angle);
        for (let i=0;i<p.length;i+=4) {
          const r=p[i], g=p[i+1], b=p[i+2], lum = .2126*r+.7152*g+.0722*b;
          if (name === 'brightness') { p[i]=r+brightness; p[i+1]=g+brightness; p[i+2]=b+brightness; }
          if (name === 'contrast') { p[i]=contrast*(r-128)+128; p[i+1]=contrast*(g-128)+128; p[i+2]=contrast*(b-128)+128; }
          if (name === 'saturation') { p[i]=lum+(r-lum)*saturation; p[i+1]=lum+(g-lum)*saturation; p[i+2]=lum+(b-lum)*saturation; }
          if (name === 'grayscale') { p[i]=r+(lum-r)*amount; p[i+1]=g+(lum-g)*amount; p[i+2]=b+(lum-b)*amount; }
          if (name === 'invert') { p[i]=r+(255-2*r)*amount; p[i+1]=g+(255-2*g)*amount; p[i+2]=b+(255-2*b)*amount; }
          if (name === 'sepia') { p[i]=r+(.393*r+.769*g+.189*b-r)*amount; p[i+1]=g+(.349*r+.686*g+.168*b-g)*amount; p[i+2]=b+(.272*r+.534*g+.131*b-b)*amount; }
          if (name === 'hue') {
            p[i]=r*(.213+co*.787-si*.213)+g*(.715-co*.715-si*.715)+b*(.072-co*.072+si*.928);
            p[i+1]=r*(.213-co*.213+si*.143)+g*(.715+co*.285+si*.140)+b*(.072-co*.072-si*.283);
            p[i+2]=r*(.213-co*.213-si*.787)+g*(.715-co*.715+si*.715)+b*(.072+co*.928+si*.072);
          }
          if (name === 'warmth') { p[i]=r+clamp(v,-100,100)*.4; p[i+2]=b-clamp(v,-100,100)*.4; }
        }
      }
      ctx.putImageData(img,0,0);
      if (this.selection) { const target = layer.canvas.getContext('2d'), s = this.selection; target.save(); this._clipSelection(target,layer); target.clearRect(s.x-layer.x,s.y-layer.y,s.w,s.h); target.drawImage(result,0,0); target.restore(); }
      else layer.canvas = result;
      this._invalidate(layer); this._commit(`${name.charAt(0).toUpperCase()+name.slice(1)}`);
    }
    _boxBlur(src,w,h,r) {
      const temp = new Float32Array(src.length), dst = new Uint8ClampedArray(src.length), span = r*2+1;
      // Work in premultiplied alpha so transparent edges retain their color.
      for(let y=0;y<h;y++) {
        const sums = [0,0,0,0];
        for(let n=-r;n<=r;n++) { const i=(y*w+Math.max(0,Math.min(w-1,n)))*4, a=src[i+3]/255; sums[0]+=src[i]*a; sums[1]+=src[i+1]*a; sums[2]+=src[i+2]*a; sums[3]+=src[i+3]; }
        for(let x=0;x<w;x++) {
          const i=(y*w+x)*4; for(let k=0;k<4;k++) temp[i+k]=sums[k]/span;
          const out=(y*w+Math.max(0,x-r))*4, incoming=(y*w+Math.min(w-1,x+r+1))*4, oa=src[out+3]/255, ia=src[incoming+3]/255;
          sums[0]+=src[incoming]*ia-src[out]*oa; sums[1]+=src[incoming+1]*ia-src[out+1]*oa; sums[2]+=src[incoming+2]*ia-src[out+2]*oa; sums[3]+=src[incoming+3]-src[out+3];
        }
      }
      for(let x=0;x<w;x++) {
        const sums = [0,0,0,0]; for(let n=-r;n<=r;n++) { const i=(Math.max(0,Math.min(h-1,n))*w+x)*4; for(let k=0;k<4;k++) sums[k]+=temp[i+k]; }
        for(let y=0;y<h;y++) {
          const i=(y*w+x)*4, alpha=sums[3]/span; dst[i+3]=alpha; const factor=alpha > 0 ? 255/(span*alpha) : 0; for(let k=0;k<3;k++) dst[i+k]=sums[k]*factor;
          const out=(Math.max(0,y-r)*w+x)*4, incoming=(Math.min(h-1,y+r+1)*w+x)*4; for(let k=0;k<4;k++) sums[k]+=temp[incoming+k]-temp[out+k];
        }
      }
      return dst;
    }
    _point(event) { const rect = this.canvas.getBoundingClientRect(); return {x:(event.clientX-rect.left)/this.zoom,y:(event.clientY-rect.top)/this.zoom}; }
    _inside(p) { return p.x >= 0 && p.y >= 0 && p.x < this.width && p.y < this.height; }
    _rect(a,b) { const x=clamp(Math.min(a.x,b.x),0,this.width), y=clamp(Math.min(a.y,b.y),0,this.height); return {x,y,w:clamp(Math.max(a.x,b.x),0,this.width)-x,h:clamp(Math.max(a.y,b.y),0,this.height)-y}; }
    _hitLayer(point) {
      for(let n=this.layers.length-1;n>=0;n--) { const l=this.layers[n]; if(!l.visible || !l.opacity) continue; const x=Math.floor(point.x-l.x),y=Math.floor(point.y-l.y); if(x<0||y<0||x>=this.width||y>=this.height) continue; if(l.canvas.getContext('2d').getImageData(x,y,1,1).data[3]>5) return l; }
      return null;
    }
    _sample(point) { if(!this._inside(point)) return; const p=this.ctx.getImageData(Math.floor(point.x),Math.floor(point.y),1,1).data; this.setColor('#'+[p[0],p[1],p[2]].map(v=>v.toString(16).padStart(2,'0')).join('')); }
    _bind() {
      this.wrapper.addEventListener('pointerdown',event => this._pointerDown(event));
      this.wrapper.addEventListener('pointermove',event => this._pointerMove(event));
      this.wrapper.addEventListener('pointerup',event => this._pointerUp(event));
      this.wrapper.addEventListener('pointercancel',event => this._pointerUp(event));
      this.wrapper.addEventListener('lostpointercapture',event => { if(this.pointer) this._pointerUp(event); });
      this.wrapper.addEventListener('contextmenu',event => event.preventDefault());
      this.wrapper.addEventListener('wheel',event => { if(event.target.closest('input,select,button')) return; event.preventDefault(); const speed = event.ctrlKey ? .007 : .0015; this.setZoom(this.zoom*Math.exp(-event.deltaY*speed),{x:event.clientX,y:event.clientY}); },{passive:false});
      document.addEventListener('keydown',event => { if(event.code==='Space' && !/INPUT|TEXTAREA|SELECT/.test(event.target.tagName) && !event.target.isContentEditable) { event.preventDefault(); this.spaceDown=true; this._cursor(); } });
      document.addEventListener('keyup',event => { if(event.code==='Space') { this.spaceDown=false; this._cursor(); } });
      window.addEventListener('blur',() => { this.spaceDown=false; if(this.pointer) this._pointerUp({pointerId:this.pointer.id}); this._cursor(); });
    }
    _pointerDown(event) {
      if(this.busy || this.pointer || event.button>1 || event.target.closest('input,select,button,a')) return;
      const point=this._point(event), pan=this.spaceDown||this.tool==='hand'||event.button===1;
      if(!pan && !this._inside(point)) return;
      event.preventDefault();
      if(event.altKey && ['brush','eraser','eyedropper'].includes(this.tool)) { this._sample(point); return; }
      if(this.tool==='eyedropper' && !pan) { this._sample(point); return; }
      if(this.tool==='zoom' && !pan) { this.setZoom(this.zoom*(event.altKey ? .8 : 1.25),{x:event.clientX,y:event.clientY}); return; }
      if(this.tool==='text' && !pan) { this._emit('textrequest',{x:point.x,y:point.y}); return; }
      if(this.tool==='fill' && !pan) { this._fill(point); return; }
      let layer=this._selected();
      if(this.tool==='move' && !pan) { const hit=this._hitLayer(point); if(hit && !hit.locked) { layer=hit; this.selectLayer(hit.id); } if(!layer || layer.locked) return; }
      if(['brush','eraser'].includes(this.tool) && !pan) { layer=this._paintable(); if(!layer) return; }
      const tool=pan?'hand':this.tool;
      this.pointer={id:event.pointerId,tool,start:point,last:point,startClient:{x:event.clientX,y:event.clientY},panX:this.panX,panY:this.panY,layer,layerX:layer?.x||0,layerY:layer?.y||0,moved:false};
      try { this.wrapper.setPointerCapture(event.pointerId); } catch (_) {}
      if(['brush','eraser'].includes(tool)) {
        this.pointer.original=cloneCanvas(layer.canvas); this.pointer.stroke=makeCanvas(this.width,this.height); this._brushSegment(point,point,event);
      }
      this._cursor(); this._drawOverlay();
    }
    _pointerMove(event) {
      const p=this.pointer; if(!p || p.id!==event.pointerId) return; event.preventDefault();
      const point=this._point(event); p.moved = p.moved || Math.abs(event.clientX-p.startClient.x)+Math.abs(event.clientY-p.startClient.y)>2;
      if(p.tool==='hand') { this.panX=p.panX+event.clientX-p.startClient.x; this.panY=p.panY+event.clientY-p.startClient.y; this._syncLayout(); }
      else if(p.tool==='move') { p.layer.x=p.layerX+Math.round(point.x-p.start.x); p.layer.y=p.layerY+Math.round(point.y-p.start.y); this._invalidate(p.layer); this.render(); }
      else if(['brush','eraser'].includes(p.tool)) { const events=event.getCoalescedEvents ? event.getCoalescedEvents() : [event]; for(const item of events.length?events:[event]) { const pt=this._point(item); this._brushSegment(p.last,pt,item); p.last=pt; } }
      else { p.last=point; this._drawOverlay(); }
      p.last=point;
    }
    _pointerUp(event) {
      const p=this.pointer; if(!p || (event.pointerId!==undefined && p.id!==event.pointerId)) return;
      this.pointer=null;
      try { if(this.wrapper.hasPointerCapture(p.id)) this.wrapper.releasePointerCapture(p.id); } catch (_) {}
      if(p.tool==='brush'||p.tool==='eraser') { this._invalidate(p.layer); this._commit(p.tool==='brush'?'Brush stroke':'Erase'); }
      else if(p.tool==='move' && p.moved) this._commit('Move layer');
      else if(p.tool==='marquee') { const r=this._rect(p.start,p.last); this.selection=r.w>1&&r.h>1?r:null; this._changed(); }
      else if(p.tool==='crop') { const r=this._rect(p.start,p.last); if(r.w>2&&r.h>2) this._crop(r); }
      else if((p.tool==='rectangle'||p.tool==='ellipse') && p.moved) {
        try {this._reserveLayer();}catch(error){this._error(error);this._drawOverlay();this._cursor();return;}
        const r=this._rect(p.start,p.last); if(r.w>0&&r.h>0) { const l=this._layer(p.tool==='rectangle'?'Rectangle':'Ellipse'),ctx=l.canvas.getContext('2d'); ctx.save(); this._clipSelection(ctx,l); ctx.fillStyle=this.color; ctx.globalAlpha=this.brushOpacity; if(p.tool==='rectangle') ctx.fillRect(r.x,r.y,r.w,r.h); else { ctx.beginPath(); ctx.ellipse(r.x+r.w/2,r.y+r.h/2,r.w/2,r.h/2,0,0,Math.PI*2); ctx.fill(); } ctx.restore(); this.layers.push(l); this.selectedLayerId=l.id; this._commit(p.tool==='rectangle'?'Draw rectangle':'Draw ellipse'); }
      }
      this._drawOverlay(); this._cursor(); if(p.tool==='hand') this._changed();
    }
    _brushSegment(from,to,event) {
      const p=this.pointer, layer=p.layer, ctx=p.stroke.getContext('2d');
      const pressure=event.pointerType==='pen'?clamp(event.pressure,.05,1):1, radius=this.brushSize*pressure/2;
      const x1=from.x-layer.x,y1=from.y-layer.y,x2=to.x-layer.x,y2=to.y-layer.y;
      ctx.save(); this._clipSelection(ctx,layer);
      if(this.brushHardness>=.98) {
        ctx.strokeStyle=this.color; ctx.fillStyle=this.color; ctx.lineWidth=radius*2; ctx.lineCap='round'; ctx.lineJoin='round';
        ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x2,y2); ctx.stroke(); ctx.beginPath();ctx.arc(x2,y2,radius,0,Math.PI*2);ctx.fill();
      } else {
        const d=Math.hypot(x2-x1,y2-y1),steps=Math.max(1,Math.ceil(d/Math.max(.5,radius*.18))), rgb=colorRGBA(this.color);
        for(let n=0;n<=steps;n++) { const t=n/steps,x=x1+(x2-x1)*t,y=y1+(y2-y1)*t,g=ctx.createRadialGradient(x,y,radius*this.brushHardness,x,y,radius); g.addColorStop(0,this.color);g.addColorStop(1,`rgba(${rgb[0]},${rgb[1]},${rgb[2]},0)`);ctx.fillStyle=g;ctx.fillRect(x-radius,y-radius,radius*2,radius*2); }
      }
      ctx.restore();
      const target=layer.canvas.getContext('2d'); target.save(); target.clearRect(0,0,this.width,this.height); target.drawImage(p.original,0,0); target.globalAlpha=this.brushOpacity; target.globalCompositeOperation=p.tool==='eraser'?'destination-out':'source-over';target.drawImage(p.stroke,0,0);target.restore();
      this.render();
    }
    _fill(point) {
      const l=this._paintable(); if(!l) return;
      const x=Math.floor(point.x-l.x),y=Math.floor(point.y-l.y); if(x<0||y<0||x>=this.width||y>=this.height) return;
      const ctx=l.canvas.getContext('2d',{willReadFrequently:true}),img=ctx.getImageData(0,0,this.width,this.height),data=img.data,w=this.width,h=this.height,index=(y*w+x)*4;
      const target=[data[index],data[index+1],data[index+2],data[index+3]],fill=Array.from(colorRGBA(this.color)); fill[3]=Math.round(this.brushOpacity*255);
      if(target.every((v,i)=>Math.abs(v-fill[i])<2)) return;
      const seen=new Uint8Array(w*h),stack=[y*w+x],sel=this.selection, tolerance=24;
      const matches=i=>Math.abs(data[i]-target[0])+Math.abs(data[i+1]-target[1])+Math.abs(data[i+2]-target[2])+Math.abs(data[i+3]-target[3])<=tolerance;
      const permitted=(xx,yy)=>!sel||(xx+l.x>=sel.x&&yy+l.y>=sel.y&&xx+l.x<sel.x+sel.w&&yy+l.y<sel.y+sel.h);
      const canPaint=(xx,yy)=>!seen[yy*w+xx]&&permitted(xx,yy)&&matches((yy*w+xx)*4);
      while(stack.length) {
        const pos=stack.pop(),yy=Math.floor(pos/w);let xx=pos%w;if(!canPaint(xx,yy))continue;
        while(xx>0&&canPaint(xx-1,yy))xx--;
        let above=false,below=false;
        while(xx<w&&canPaint(xx,yy)){
          const i=(yy*w+xx)*4;seen[yy*w+xx]=1;
          // Blend paint over the original pixel, retaining the layer's alpha.
          const sa=fill[3]/255,da=data[i+3]/255,oa=sa+da*(1-sa);for(let k=0;k<3;k++)data[i+k]=oa?(fill[k]*sa+data[i+k]*da*(1-sa))/oa:0;data[i+3]=oa*255;
          if(yy>0){const next=canPaint(xx,yy-1);if(next&&!above)stack.push((yy-1)*w+xx);above=next;}
          if(yy<h-1){const next=canPaint(xx,yy+1);if(next&&!below)stack.push((yy+1)*w+xx);below=next;}
          xx++;
        }
      }
      ctx.putImageData(img,0,0);this._invalidate(l);this._commit('Fill');
    }
    _drawOverlay() {
      const ctx=this.overlay.getContext('2d');ctx.clearRect(0,0,this.width,this.height);const p=this.pointer;
      const r=p&&['marquee','crop','rectangle','ellipse'].includes(p.tool)?this._rect(p.start,p.last):this.selection;
      if(!r) return;
      ctx.save();
      if(p&&p.tool==='crop') {ctx.fillStyle='#0009';ctx.fillRect(0,0,this.width,r.y);ctx.fillRect(0,r.y+r.h,this.width,this.height-r.y-r.h);ctx.fillRect(0,r.y,r.x,r.h);ctx.fillRect(r.x+r.w,r.y,this.width-r.x-r.w,r.h);}
      if(p&&['rectangle','ellipse'].includes(p.tool)) {ctx.fillStyle=this.color;ctx.globalAlpha=.7*this.brushOpacity;if(p.tool==='rectangle')ctx.fillRect(r.x,r.y,r.w,r.h);else {ctx.beginPath();ctx.ellipse(r.x+r.w/2,r.y+r.h/2,r.w/2,r.h/2,0,0,Math.PI*2);ctx.fill();}ctx.globalAlpha=1;}
      ctx.lineWidth=1/this.zoom;ctx.strokeStyle='#ffffff';ctx.strokeRect(r.x,r.y,r.w,r.h);ctx.strokeStyle='#1e2839';ctx.setLineDash([5/this.zoom,5/this.zoom]);ctx.strokeRect(r.x,r.y,r.w,r.h);
      if(p&&p.tool==='crop') {ctx.setLineDash([]);ctx.strokeStyle='#ffffff88';ctx.beginPath();for(let k=1;k<3;k++){ctx.moveTo(r.x+r.w*k/3,r.y);ctx.lineTo(r.x+r.w*k/3,r.y+r.h);ctx.moveTo(r.x,r.y+r.h*k/3);ctx.lineTo(r.x+r.w,r.y+r.h*k/3);}ctx.stroke();}
      ctx.restore();
    }
    copySelection() {
      const l=this._selected(); if(!l) return null; const r=this.selection||{x:0,y:0,w:this.width,h:this.height};
      const c=makeCanvas(r.w,r.h),ctx=c.getContext('2d');ctx.globalAlpha=l.opacity;ctx.drawImage(l.canvas,l.x-r.x,l.y-r.y);return c.toDataURL('image/png');
    }
    _makeDemo() {
      this.width=1400;this.height=980;this.name='Alpine reverie';
      let seed=42831;const random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
      const poly=(ctx,points,fill)=>{ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(...p):ctx.moveTo(...p));ctx.closePath();ctx.fillStyle=fill;ctx.fill();};
      const gradient=(ctx,x1,y1,x2,y2,stops)=>{const g=ctx.createLinearGradient(x1,y1,x2,y2);stops.forEach(([p,c])=>g.addColorStop(p,c));return g;};
      const texture=(c,strength)=>{const ctx=c.getContext('2d'),img=ctx.getImageData(0,0,c.width,c.height),p=img.data;for(let i=0;i<p.length;i+=4){if(!p[i+3])continue;const noise=(random()-.5)*strength;p[i]+=noise;p[i+1]+=noise;p[i+2]+=noise;}ctx.putImageData(img,0,0);};
      const sky=this._layer('01 · Apricot sky'),s=sky.canvas.getContext('2d');
      s.fillStyle=gradient(s,0,0,0,780,[[0,'#64858e'],[.35,'#b4c1b8'],[.64,'#f2cdac'],[.9,'#e5ba9d'],[1,'#acc0b5']]);s.fillRect(0,0,1400,980);
      const glow=s.createRadialGradient(1060,320,20,1060,320,680);glow.addColorStop(0,'#ffe8bdc0');glow.addColorStop(.28,'#ffe0b54a');glow.addColorStop(1,'#ffe8bd00');s.fillStyle=glow;s.fillRect(0,0,1400,800);
      for(let n=0;n<13;n++){const y=100+n*25,x=random()*1300,rx=130+random()*300,g=s.createRadialGradient(x,y,0,x,y,rx);g.addColorStop(0,'#fff0d913');g.addColorStop(1,'#fff0d900');s.save();s.translate(0,y);s.scale(1,.1);s.fillStyle=g;s.fillRect(0,-y*10,1400,7000);s.restore();}
      texture(sky.canvas,4);
      const sun=this._layer('02 · Morning light'),u=sun.canvas.getContext('2d');
      const halo=u.createRadialGradient(1088,290,0,1088,290,190);halo.addColorStop(0,'#fff0bd70');halo.addColorStop(1,'#fff0bd00');u.fillStyle=halo;u.fillRect(800,0,600,600);u.fillStyle='#fff2cf';u.beginPath();u.arc(1088,290,41,0,Math.PI*2);u.fill();
      const mountain=this._layer('03 · The high peaks'),m=mountain.canvas.getContext('2d');
      poly(m,[[0,555],[100,492],[175,445],[240,459],[365,365],[430,380],[520,300],[610,382],[720,341],[810,438],[920,366],[1000,399],[1110,341],[1220,445],[1330,405],[1400,445],[1400,720],[0,720]],gradient(m,0,330,0,750,[[0,'#8e9d99'],[1,'#bdbaa6']]));
      poly(m,[[0,680],[0,564],[80,506],[154,543],[251,436],[330,493],[425,393],[496,435],[587,309],[664,359],[716,248],[764,297],[797,284],[859,365],[891,347],[984,470],[1068,430],[1135,489],[1250,453],[1400,572],[1400,740]],gradient(m,200,300,1100,730,[[0,'#738585'],[.45,'#7c8f8a'],[1,'#bcc4af']]));
      // Lit granite faces and long, cool planes give each summit its own form.
      poly(m,[[359,522],[587,309],[568,385],[600,414],[538,467],[550,511],[490,545],[452,620]],gradient(m,410,330,650,650,[[0,'#e8d2ae'],[.5,'#c8b79a'],[1,'#8ca195']]));
      poly(m,[[460,585],[587,309],[664,359],[716,248],[691,353],[708,403],[662,465],[635,536],[588,562],[579,654]],gradient(m,610,260,760,630,[[0,'#e6d2b2'],[.38,'#a7b09f'],[1,'#617e7c']]));
      poly(m,[[716,248],[764,297],[797,284],[859,365],[891,347],[984,470],[1010,610],[874,649],[810,537],[775,462],[731,379]],gradient(m,730,270,930,660,[[0,'#bfbb9f'],[.45,'#6d8582'],[1,'#75988d']]));
      poly(m,[[716,248],[691,353],[708,403],[662,465],[635,536],[720,486],[758,413],[731,379]],'#5b797a');
      poly(m,[[797,284],[776,340],[810,368],[797,404],[839,450],[857,414],[831,361]],'#d4c7a6');
      poly(m,[[891,347],[875,409],[914,448],[895,486],[962,523],[982,496],[945,446]],'#a4af9c');
      poly(m,[[587,309],[569,373],[583,360],[594,378],[607,360],[619,366]],'#ecdfbd');
      poly(m,[[716,248],[691,314],[708,301],[715,324],[727,294],[752,313],[739,282]],'#efe1be');
      poly(m,[[797,284],[783,312],[798,307],[811,321]],'#e7d8b7');
      // Fine fractured strata follow the ridge and fade into the atmospheric base.
      m.save();m.globalAlpha=.2;m.lineWidth=1;
      for(let i=0;i<170;i++){const y=365+random()*270,x=380+random()*570;m.strokeStyle=random()>.5?'#e6d4b0':'#355f65';m.beginPath();m.moveTo(x,y);m.lineTo(x+(random()-.5)*70,y+20+random()*55);m.stroke();}m.restore();
      poly(m,[[0,667],[95,610],[180,648],[254,595],[343,630],[420,593],[480,639],[560,617],[642,666],[724,632],[818,671],[926,600],[1036,652],[1148,594],[1260,644],[1400,587],[1400,755],[0,755]],gradient(m,0,580,0,755,[[0,'#4a7372'],[1,'#8eaea0']]));
      const mist=m.createLinearGradient(0,575,0,750);mist.addColorStop(0,'#d4cfac00');mist.addColorStop(1,'#d2ceb0a0');m.fillStyle=mist;m.fillRect(0,575,1400,175);texture(mountain.canvas,9);
      const water=this._layer('04 · Mirror lake'),w=water.canvas.getContext('2d');
      w.fillStyle=gradient(w,0,666,0,980,[[0,'#93afa2'],[.25,'#71968c'],[1,'#315b61']]);w.fillRect(0,673,1400,307);
      w.save();w.beginPath();w.rect(0,673,1400,307);w.clip();w.globalAlpha=.25;w.translate(0,1388);w.scale(1,-.72);w.drawImage(mountain.canvas,0,0);w.restore();
      const reflection=w.createLinearGradient(1088,680,1050,980);reflection.addColorStop(0,'#f0d7a744');reflection.addColorStop(1,'#f0d7a700');w.fillStyle=reflection;poly(w,[[1052,680],[1120,680],[1230,980],[900,980]],reflection);
      for(let i=0;i<640;i++){const y=678+random()*302,t=(y-678)/302,x=random()*1400,len=2+random()*(10+t*80);w.strokeStyle=random()>.5?`rgba(209,218,188,${.025+random()*.10})`:`rgba(31,68,75,${.03+random()*.11})`;w.lineWidth=.3+t*.8;w.beginPath();w.moveTo(x,y);w.lineTo(x+len,y);w.stroke();}
      texture(water.canvas,5);
      const shore=this._layer('05 · Evergreen shore'),f=shore.canvas.getContext('2d');
      poly(f,[[0,716],[90,719],[169,731],[233,753],[290,759],[352,790],[453,813],[410,832],[320,829],[240,807],[124,787],[0,780]],'#294b4f');
      poly(f,[[1400,703],[1320,726],[1273,750],[1200,766],[1160,791],[1124,803],[1175,816],[1280,810],[1400,793]],'#335957');
      const tree=(x,y,h,color)=>{f.fillStyle=color;f.fillRect(x-h*.018,y-h*.65,h*.036,h*.67);for(let n=0;n<8;n++){const t=n/8,yy=y-h+t*h*.85,half=(.025+t*.19)*h;poly(f,[[x,yy-h*.2],[x-half,yy+h*.15],[x+half,yy+h*.15]],color);}};
      for(let i=0;i<65;i++){const x=random()*350,y=726+x*.23+random()*12,h=40+random()*118*(1-x/530);tree(x,y,h,random()>.5?'#27494b':'#315556');}
      for(let i=0;i<42;i++){const x=1180+random()*250,y=770-(x-1180)*.18+random()*13,h=40+random()*105;tree(x,y,h,random()>.5?'#2c5152':'#365f5b');}
      // Near shore anchors the view, with warm grasses catching the first light.
      poly(f,[[0,886],[85,878],[170,887],[232,873],[281,899],[322,927],[420,947],[492,980],[0,980]],gradient(f,0,875,0,980,[[0,'#355151'],[1,'#233d42']]));
      for(let i=0;i<110;i++){const x=random()*390,y=890+x*.2+random()*45;f.strokeStyle=random()>.4?'#627262':'#b0a078';f.lineWidth=.7+random();f.beginPath();f.moveTo(x,y);f.quadraticCurveTo(x-5,y-15,x+(random()-.5)*12,y-18-random()*30);f.stroke();}
      tree(47,978,245,'#213f44');tree(132,969,188,'#244348');tree(11,931,209,'#27494b');texture(shore.canvas,7);
      this.layers=[sky,sun,mountain,water,shore];this.selectedLayerId=mountain.id;
    }
  }
  // Restores decode asynchronously. Keep synchronous document mutations out of that window.
  for (const method of ['newDocument','addLayer','duplicateLayer','deleteLayer','selectLayer','updateLayer','reorderLayer','mergeDown','flatten','clearSelection','selectAll','deleteSelected','resizeDocument','rotateDocument','flipDocument','addText','applyFilter']) {
    const original=PrismEditor.prototype[method];
    PrismEditor.prototype[method]=function(...args){if(this.busy){this._emit('notice','Please wait for the current operation to finish.');return;}this._finishGesture();return original.apply(this,args);};
  }
  window.PrismEditor=PrismEditor;
})();
