/* Prism desktop interface. All image operations live in editor.js. */
(() => {
  'use strict';
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const iconPaths = {
    move:'<path d="M4 3v15l4-4 3 6 3-1-3-6h6Z"/>',
    marquee:'<rect x="3.5" y="4.5" width="17" height="15" rx=".5" stroke-dasharray="2.2 2.7"/>',
    brush:'<path d="m13 11 6-7a2 2 0 0 1 3 3l-7 6M13 11l2 2-4 5-4-4Z"/><path d="M7 14c-5 0-1 6-5 6 8 3 11-2 7-5"/>',
    eraser:'<path d="m14 3 7 7-9 10H6l-5-5Z"/><path d="m7 9 8 8M12 20h10"/>',
    rectangle:'<rect x="3.5" y="4.5" width="17" height="15" rx=".5"/>',
    ellipse:'<ellipse cx="12" cy="12" rx="9" ry="7.5"/>',
    fill:'<path d="m5 4 13 13M10 3l9 9-9 9-9-9 9-9ZM2 12h17M21 15s-3 3.4-3 5a3 3 0 0 0 6 0c0-1.6-3-5-3-5Z"/>',
    eyedropper:'<path d="m15 3 6 6M14 4l3-3 6 6-3 3M16 7 4 19l-1 3 3-1L18 9M6 16l3 3"/>',
    text:'<path d="M4 6V3h16v3M12 3v18M8 21h8"/>',
    crop:'<path d="M6 2v16h16M2 6h16v16M6 6l14 14"/>',
    hand:'<path d="M8 11V5a1.6 1.6 0 0 1 3.2 0v6-8a1.6 1.6 0 0 1 3.2 0v8-6a1.6 1.6 0 0 1 3.2 0v7-3a1.6 1.6 0 0 1 3.2 0v7c0 4-3 6-7 6h-1c-2 0-3-1-4-3l-5-6c-2-3 1-4 3-2l1 1Z"/>',
    zoom:'<circle cx="10" cy="10" r="6.5"/><path d="m15 15 6 6M7 10h6M10 7v6"/>',
    plus:'<path d="M12 5v14M5 12h14"/>', minus:'<path d="M5 12h14"/>',
    plusSquare:'<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M12 8v8M8 12h8"/>',
    duplicate:'<rect x="8" y="8" width="13" height="13" rx="2"/><path d="M16 8V3H3v13h5"/>',
    merge:'<path d="M4 4h16v5H4ZM4 15h16v5H4ZM12 9v6m-3-3 3 3 3-3"/>',
    trash:'<path d="M3 6h18M9 6V3h6v3M6 6l1 15h10l1-15M10 10v7M14 10v7"/>',
    lock:'<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V6a4 4 0 0 1 8 0v4M12 14v3"/>',
    unlock:'<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V6a4 4 0 0 1 7.5-2M12 14v3"/>',
    eye:'<path d="M2 12s3-6 10-6 10 6 10 6-3 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="2.7"/>',
    eyeOff:'<path d="m3 3 18 18M9 6.4A12 12 0 0 1 12 6c7 0 10 6 10 6a15 15 0 0 1-3 3.7M6 8C3.4 9.7 2 12 2 12s3 6 10 6a12 12 0 0 0 4-.7"/>',
    document:'<path d="M5 3h9l5 5v13H5ZM14 3v6h5"/>',
    export:'<path d="M12 15V2m-4 4 4-4 4 4M5 10H3v11h18V10h-2"/>',
    maximize:'<path d="M9 3H3v6M15 3h6v6M3 15v6h6M21 15v6h-6"/>',
    swap:'<path d="M4 8h16m-3-3 3 3-3 3M20 16H4m3-3-3 3 3 3"/>',
    help:'<circle cx="12" cy="12" r="9"/><path d="M9.5 8a2.6 2.6 0 0 1 5 1c0 2-2.5 2-2.5 4M12 17h.01"/>',
    more:'<path d="M5 6h14M5 12h14M5 18h14"/>', close:'<path d="m6 6 12 12M6 18 18 6"/>',
    history:'<path d="M4 4v6h6M4 10a8 8 0 1 1 .5 7M12 7v5l3 2"/>',
    monitor:'<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M12 17v4M7 21h10"/>',
    square:'<rect x="4" y="4" width="16" height="16" rx="1"/>', portrait:'<rect x="6" y="2" width="12" height="20" rx="1"/>',
    check:'<path d="m5 12 4 4L19 6"/>', open:'<path d="M3 6h7l2 3h9l-3 12H3ZM3 9V4h7l2 2h7v3"/>',
    save:'<path d="M3 3h15l3 3v15H3ZM7 3v7h10V3M7 21v-7h10v7"/>',
    undo:'<path d="M8 5 3 10l5 5M3 10h11c7 0 7 10 0 10"/>', redo:'<path d="m16 5 5 5-5 5m5-5H10c-7 0-7 10 0 10"/>',
    filter:'<path d="M4 7h16M4 17h16M8 4v6M16 14v6"/>',
    image:'<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="15.5" cy="8.5" r="1.5"/><path d="m3 17 6-7 6 7 3-3 3 3"/>'
  };
  const svg = name => `<svg viewBox="0 0 24 24" aria-hidden="true">${iconPaths[name] || iconPaths.document}</svg>`;
  $$('[data-icon]').forEach(el => el.innerHTML = svg(el.dataset.icon));
  const native = !!window.webkit?.messageHandlers?.prism;
  const bridge = message => { if (native) window.webkit.messageHandlers.prism.postMessage(message); };
  let editor, state, clipboard = null, lastSavedName = '', lastStateKey = '', lastPreviewKey = '', toastTimer, hue = 38, saturation = .5, value = .9, textSize = 56, textFont = '-apple-system', activePanel = 'layers', liveMenu = null, modalCancelCallback = null, loadBusy = false;
  const tools = [
    ['move','Move','V','Move the selected layer'],['marquee','Rectangular selection','M','Drag to select · Delete to clear'],
    ['brush','Brush','B','Drag to paint · Option to sample color'],['eraser','Eraser','E','Drag to erase the selected layer'],
    ['rectangle','Rectangle','U','Drag to draw a rectangle'],['ellipse','Ellipse','⇧U','Drag to draw an ellipse'],
    ['fill','Paint bucket','G','Click to fill a connected area'],['eyedropper','Eyedropper','I','Click to sample a color'],
    ['text','Text','T','Click to add a text layer'],['crop','Crop','C','Drag a rectangle to crop the document'],
    ['hand','Hand','H','Drag to pan the document'],['zoom','Zoom','Z','Click to zoom · Option-click to zoom out']
  ];
  const menus = {
    File:[['New document…','new','⌘N','plusSquare'],['Open…','open','⌘O','open'],['Place image…','place','','image'],null,['Save project','save','⌘S','save'],['Save project as…','saveAs','⇧⌘S'],['Export image…','export','⇧⌘E','export']],
    Edit:[['Undo','undo','⌘Z','undo'],['Redo','redo','⇧⌘Z','redo'],null,['Cut','cut','⌘X'],['Copy','copy','⌘C'],['Paste','paste','⌘V'],null,['Clear selection','deleteSelected','⌫']],
    Image:[['Image size…','resize','','image'],null,['Rotate 90° clockwise','rotateCW'],['Rotate 90° counterclockwise','rotateCCW'],['Rotate 180°','rotate180'],null,['Flip horizontal','flipHorizontal'],['Flip vertical','flipVertical']],
    Layer:[['New layer','addLayer','⇧⌘N','plusSquare'],['Duplicate layer','duplicate','⌘J','duplicate'],['Rename layer…','renameLayer'],['Lock / unlock layer','lockLayer','','lock'],null,['Merge down','mergeDown','','merge'],['Flatten image','flatten'],null,['Delete layer','deleteLayer','','trash']],
    Select:[['Select all','selectAll','⌘A','marquee'],['Deselect','deselect','⌘D'],['Delete selected pixels','deleteSelected','⌫']],
    Filter:[['Brightness…','brightness','','filter'],['Contrast…','contrast'],['Saturation…','saturation'],['Hue…','hue'],null,['Gaussian blur…','blur'],['Sharpen…','sharpen'],null,['Black & white','grayscale'],['Sepia','sepia'],['Invert','invert']],
    View:[['Zoom in','zoomIn','⌘+','zoom'],['Zoom out','zoomOut','⌘−'],['Zoom to…','zoom'],null,['Fit to view','fit','⌘0','maximize'],['Actual size','actual','⌘1'],null,['Show layers','showLayers'],['Show history','showHistory']],
    Help:[['Keyboard shortcuts','help','','help'],['About Prism','about']]
  };

  function toast(message) {
    const el = $('#toast'); el.textContent = message; el.classList.add('visible');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('visible'), 3000);
  }
  function closeMenu() {
    $('#menuOverlay').hidden = true; $('#menuOverlay').innerHTML = ''; liveMenu = null;
    $$('.menu-trigger').forEach(el => el.classList.remove('active'));
  }
  function openMenu(name, anchor, entries) {
    if (liveMenu === name) return closeMenu();
    closeMenu(); liveMenu = name;
    const overlay = $('#menuOverlay'); overlay.hidden = false;
    const menu = document.createElement('div'); menu.className = 'dropdown-menu'; menu.setAttribute('role','menu');
    const rect = anchor.getBoundingClientRect(); menu.style.top = `${rect.bottom + 2}px`; menu.style.left = `${Math.min(rect.left, innerWidth - 240)}px`;
    (entries || menus[name]).forEach(item => {
      if (!item) { const separator = document.createElement('div'); separator.className = 'dropdown-separator'; menu.append(separator); return; }
      const [label, command, shortcut = '', icon = ''] = item;
      const button = document.createElement('button'); button.className = 'dropdown-item'; button.setAttribute('role','menuitem');
      button.innerHTML = `${icon ? svg(icon) : ''}<span>${label}</span><span>${shortcut}</span>`;
      button.disabled = isDisabled(command); button.onclick = () => { closeMenu(); run(command); }; menu.append(button);
    });
    overlay.append(menu); overlay.onpointerdown = event => { if (event.target === overlay) closeMenu(); };
    requestAnimationFrame(() => { if (menu.getBoundingClientRect().bottom > innerHeight - 10) menu.style.top = `${Math.max(8,innerHeight-menu.offsetHeight-10)}px`; });
  }
  Object.keys(menus).forEach(name => {
    const button = document.createElement('button'); button.className = 'menu-trigger'; button.textContent = name;
    button.setAttribute('aria-haspopup','menu'); button.onclick = () => { openMenu(name,button); if (liveMenu) button.classList.add('active'); };
    button.onpointerenter = () => { if (liveMenu && liveMenu !== name) { openMenu(name,button); button.classList.add('active'); } };
    $('#mainMenus').append(button);
  });
  tools.forEach(([name,label,key],index) => {
    if ([2,6,10].includes(index)) { const separator = document.createElement('div'); separator.className = 'tool-separator'; $('#toolButtons').append(separator); }
    const button = document.createElement('button'); button.className = 'tool-button'; button.dataset.tool = name; button.title = `${label} (${key})`; button.setAttribute('aria-label',`${label} (${key})`);
    button.innerHTML = svg(name); button.onclick = () => editor.setTool(name); $('#toolButtons').append(button);
  });
  const swatchColors = ['#f3ede0','#dfbd7f','#bc7d5c','#9e6062','#7f7494','#637e8d','#809b89','#303642','#171719'];
  swatchColors.forEach(color => { const button = document.createElement('button'); button.className='swatch'; button.style.background=color; button.title=color; button.setAttribute('aria-label',`Use color ${color}`); button.onclick=()=>editor.setColor(color); $('#swatches').append(button); });

  function isDisabled(command) {
    if (!state) return true;
    if ((state.busy || loadBusy) && !['help','about','showLayers','showHistory'].includes(command)) return true;
    const layer = selectedLayer();
    if (command === 'undo') return state.historyIndex <= 0;
    if (command === 'redo') return state.historyIndex >= state.history.length - 1;
    if (command === 'mergeDown') return !layer || state.layers.findIndex(l=>l.id===layer.id) < 1;
    if (['deleteLayer','duplicate','renameLayer','lockLayer'].includes(command)) return !layer;
    return false;
  }
  function selectedLayer() { return state?.layers.find(layer => layer.id === state.selectedLayerId); }
  function setPanel(name) {
    activePanel = name; $('#layersTab').classList.toggle('active', name === 'layers'); $('#historyTab').classList.toggle('active', name === 'history');
    $('#layersView').hidden = name !== 'layers'; $('#historyView').hidden = name !== 'history';
  }
  function escapeHTML(value) { return String(value ?? '').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c])); }
  function sync() {
    state = editor.getState();
    const zoom = Math.round(state.zoom * 100);
    $('#documentName').textContent = state.name || 'Untitled'; $('#documentZoom').textContent = `${zoom}%`; $('#dirtyDot').classList.toggle('visible',!!state.dirty);
    $('#documentDimensions').textContent = `${state.width.toLocaleString()} × ${state.height.toLocaleString()} px`;
    $('#statusZoom').textContent = `${zoom}%`; $('#navigatorZoom').textContent = `${zoom}%`; $('#zoomRange').value = zoom;
    document.title = `${state.name || 'Untitled'}${state.dirty ? ' •' : ''} — Prism`;
    $('#foregroundSwatch span').style.background = state.color; $('#backgroundSwatch span').style.background = state.secondaryColor;
    $('#hexColorButton').textContent = state.color.toUpperCase();
    $$('.swatch').forEach(el=>el.classList.toggle('selected',el.title.toLowerCase()===state.color.toLowerCase()));
    const tool = tools.find(t=>t[0]===state.tool) || tools[0];
    $$('.tool-button').forEach(el=>{ el.classList.toggle('active',el.dataset.tool===state.tool); el.setAttribute('aria-pressed',el.dataset.tool===state.tool); });
    $('#currentToolIcon').innerHTML = svg(state.tool); $('#currentToolIcon').title = tool[1]; $('#toolHint').textContent = state.busy || loadBusy ? 'Working…' : tool[3];
    $('#workspace').classList.toggle('busy',state.busy || loadBusy);
    $$('.tool-button').forEach(button=>button.disabled=state.busy || loadBusy);
    renderToolOptions(); renderLayers(); renderHistory();
    const previewKey = JSON.stringify([state.name,state.width,state.height,state.historyIndex,state.history.length,state.layers.map(l=>[l.id,l.thumbnail,l.visible,l.opacity,l.blendMode,l.x,l.y])]);
    if(previewKey!==lastPreviewKey){try { $('#navigatorImage').src = editor.exportImage('png');lastPreviewKey=previewKey; } catch (_) {}}
    const key = `${state.name}|${state.dirty}|${!!(state.busy||loadBusy)}`;
    if (lastStateKey !== key) { lastStateKey = key; bridge({action:'state',name:state.name,dirty:state.dirty,busy:!!(state.busy||loadBusy)}); }
    const hsv=hexToHSV(state.color); hue=hsv.h; saturation=hsv.s; value=hsv.v; updateColorField();
  }
  let lastOptionsKey = '';
  function renderToolOptions() {
    const key = `${state.tool}`;
    if (lastOptionsKey !== key) {
      lastOptionsKey = key; const container = $('#toolOptions');
      const mode = `<div class="option-group"><span class="option-label">Mode</span><span class="option-text">Normal</span></div>`;
      const size = `<label class="option-group"><span class="option-label">Size</span><input class="option-field" id="brushSize" type="number" min="1" max="500" value="${state.brushSize}"><span class="option-label">px</span></label>`;
      const opacity = `<label class="option-group"><span class="option-label">Opacity</span><input class="option-field small" id="brushOpacity" type="number" min="1" max="100" value="${Math.round(state.brushOpacity * 100)}"><span class="option-label">%</span></label>`;
      const options = {
        move:`<span class="option-text">Move selected layer</span><span class="option-divider"></span><button class="plain-button" data-command="selectAll">Select all</button><button class="plain-button" data-command="deselect">Deselect</button>`,
        brush:`${size}${mode}${opacity}<span class="option-text">⌥ to sample</span>`,
        eraser:`${size}${opacity}<span class="option-text">Erase to transparency</span>`,
        rectangle:`${opacity}<span class="option-text">Drag to draw · Foreground fill</span>`,
        ellipse:`${opacity}<span class="option-text">Drag to draw · Foreground fill</span>`,
        marquee:`<span class="option-text">Rectangular selection</span><button class="plain-button" data-command="deselect">Deselect</button><button class="plain-button" data-command="deleteSelected">Clear pixels</button>`,
        crop:`<span class="option-text">Drag across the canvas to crop</span><span class="option-divider"></span><span class="option-text">⌘Z to restore</span>`,
        fill:`${opacity}<span class="option-text">Fill connected pixels with foreground color</span>`,
        eyedropper:`<span class="option-text">Sample the visible image</span><span class="option-divider"></span><span class="option-text">Click any pixel to choose its color</span>`,
        text:`<label class="option-group"><select id="textFont" class="option-field option-select" aria-label="Text font"><option value="-apple-system">System Sans</option><option value="Georgia">Georgia</option><option value="Helvetica Neue">Helvetica Neue</option><option value="Menlo">Menlo</option></select></label><label class="option-group"><span class="option-label">Size</span><input id="textSize" type="number" min="6" max="800" class="option-field" value="${textSize}"><span class="option-label">px</span></label><span class="option-text">Click canvas to add text</span>`,
        hand:`<span class="option-text">Drag to explore your canvas</span><span class="option-divider"></span><span class="option-text">Hold Space from any tool</span>`,
        zoom:`<button class="plain-button" data-command="zoomIn">Zoom in</button><button class="plain-button" data-command="zoomOut">Zoom out</button><span class="option-divider"></span><span class="option-text">⌥ click to zoom out · Scroll to zoom</span>`
      };
      container.innerHTML=options[state.tool]||'';
      $('#brushSize')?.addEventListener('change', event => editor.setBrushSize(clamp(+event.target.value,1,500)));
      $('#brushOpacity')?.addEventListener('change', event => editor.setBrushOpacity(clamp(+event.target.value,1,100)/100));
      if ($('#textSize')) $('#textSize').onchange = event => { textSize=clamp(+event.target.value,6,800); };
      if ($('#textFont')) { $('#textFont').value=textFont; $('#textFont').onchange=event=>textFont=event.target.value; }
    }
    if ($('#brushSize') && document.activeElement !== $('#brushSize')) $('#brushSize').value=state.brushSize;
    if ($('#brushOpacity') && document.activeElement !== $('#brushOpacity')) $('#brushOpacity').value=Math.round(state.brushOpacity*100);
  }
  function renderLayers() {
    const list = $('#layerList'); const scrollTop=list.scrollTop; list.innerHTML=''; $('#layerCount').textContent=state.layers.length;
    [...state.layers].reverse().forEach((layer,index) => {
      const row=document.createElement('div'); row.className=`layer-row${layer.id===state.selectedLayerId?' selected':''}${layer.locked?' locked':''}`;
      row.dataset.id=layer.id; row.draggable=true; row.setAttribute('role','option'); row.setAttribute('aria-selected',layer.id===state.selectedLayerId);
      row.innerHTML=`<button class="layer-eye ${layer.visible?'':'hidden-eye'}" title="${layer.visible?'Hide':'Show'} layer" aria-label="${layer.visible?'Hide':'Show'} ${escapeHTML(layer.name)}">${svg(layer.visible?'eye':'eyeOff')}</button><img class="layer-thumbnail" alt="" src="${layer.thumbnail||''}"><div class="layer-info"><div class="layer-name">${escapeHTML(layer.name)}</div><div class="layer-detail">${layer.locked?'Locked layer':Math.round(layer.opacity*100)+'% · '+(['source-over','normal'].includes(layer.blendMode)?'Normal':(layer.blendMode||'Normal').replace('-',' '))}</div></div>${layer.locked?`<span class="layer-locked-icon">${svg('lock')}</span>`:''}`;
      row.onclick=()=>{if(!editor.busy&&!loadBusy)editor.selectLayer(layer.id);};
      $('.layer-eye',row).onclick=event=>{event.stopPropagation();editor.updateLayer(layer.id,{visible:!layer.visible});};
      $('.layer-info',row).ondblclick=event=>{event.stopPropagation();renameLayer(layer.id);};
      row.oncontextmenu=event=>{event.preventDefault();editor.selectLayer(layer.id);openMenu('layerContext',row,menus.Layer);};
      row.ondragstart=event=>{event.dataTransfer.setData('text/plain',String(layer.id));event.dataTransfer.effectAllowed='move';};
      row.ondragover=event=>{event.preventDefault();row.classList.add('drag-over');event.dataTransfer.dropEffect='move';};
      row.ondragleave=()=>row.classList.remove('drag-over');
      row.ondrop=event=>{event.preventDefault();row.classList.remove('drag-over');const id=event.dataTransfer.getData('text/plain');const actual=state.layers.find(l=>String(l.id)===id);if(actual)editor.reorderLayer(actual.id,state.layers.length-1-index);};
      list.append(row);
    }); list.scrollTop=scrollTop;
    const layer=selectedLayer(); $('#blendMode').disabled=!layer||state.busy||loadBusy; $('#layerOpacity').disabled=!layer||state.busy||loadBusy; $('#lockLayer').disabled=!layer||state.busy||loadBusy;
    if(layer){$('#blendMode').value=layer.blendMode==='source-over'?'normal':layer.blendMode||'normal';if(document.activeElement!==$('#layerOpacity'))$('#layerOpacity').value=Math.round(layer.opacity*100);$('#lockLayer').innerHTML=svg(layer.locked?'lock':'unlock');$('#lockLayer').classList.toggle('active',layer.locked);}
    $$('[data-command="mergeDown"],[data-command="deleteLayer"],[data-command="duplicate"]').forEach(el=>el.disabled=isDisabled(el.dataset.command));
  }
  function renderHistory() {
    $('#historyList').innerHTML='';
    [...state.history].reverse().forEach((entry, reversedIndex)=>{
      const index=state.history.length-1-reversedIndex; const button=document.createElement('button'); button.className=`history-item${index===state.historyIndex?' current':''}${index>state.historyIndex?' future':''}`;
      button.style.width='100%'; button.innerHTML=`${svg('history')}<span>${escapeHTML(entry.name||entry.label||'Edit')}</span><span>${index===state.historyIndex?'Current':''}</span>`;
      button.onclick=async()=>{if(loadBusy||editor.busy)return;try{if(editor.goToHistory)await editor.goToHistory(index);else{let current=editor.getState().historyIndex;while(current!==index){await(current>index?editor.undo():editor.redo());current=editor.getState().historyIndex;}}}catch(error){toast(error.message||'Could not restore this step');}};$('#historyList').append(button);
    });
  }
  function renameLayer(id=state.selectedLayerId) {
    const layer=state.layers.find(l=>l.id===id); if(!layer)return;
    const row=$$('.layer-row').find(el=>el.dataset.id===String(id)); if(!row)return;
    const name=$('.layer-name',row), input=document.createElement('input'); input.className='layer-name-input'; input.value=layer.name; name.replaceChildren(input);input.focus();input.select();
    let done=false; const commit=()=>{if(done)return;done=true;const val=input.value.trim();if(val)editor.updateLayer(id,{name:val});else sync();};
    input.onblur=commit; input.onkeydown=event=>{event.stopPropagation();if(event.key==='Enter')commit();if(event.key==='Escape'){done=true;sync();}};
  }

  function showModal(title, content, buttons, options={}) {
    closeMenu();
    if(modalCancelCallback){const previous=modalCancelCallback;modalCancelCallback=null;previous();}
    modalCancelCallback=options.onClose||null;
    $('#modalRoot').innerHTML=`<div class="modal-backdrop"><section class="modal ${options.wide?'wide':''}" role="dialog" aria-modal="true" aria-labelledby="modalTitle"><div class="modal-header"><h2 id="modalTitle">${title}</h2><button class="icon-button modal-close" title="Close">${svg('close')}</button></div>${options.subtitle?`<p class="modal-subtitle">${options.subtitle}</p>`:''}<div class="modal-content">${content}</div><div class="modal-footer">${buttons.map((button,index)=>`<button class="modal-button ${button.primary?'primary':''}" data-modal-action="${index}">${button.label}</button>`).join('')}</div></section></div>`;
    $('.modal-close').onclick=closeModal;
    $$('.modal-button').forEach(button=>button.onclick=async()=>{const item=buttons[+button.dataset.modalAction];try{await item.action();}catch(error){toast(error.message||String(error));}});
    $('.modal-backdrop').onpointerdown=event=>{if(event.target.classList.contains('modal-backdrop'))closeModal();};
    requestAnimationFrame(()=>{ const first=$('.modal input:not([type=range]),.modal textarea,.modal select');if(first){first.focus();if(first.type==='text')first.select();} });
  }
  function closeModal() { $('#modalRoot').innerHTML='';if(modalCancelCallback){const callback=modalCancelCallback;modalCancelCallback=null;callback();}$('#workspace').focus(); }
  async function confirmReplace() {
    if(editor.busy||loadBusy){toast('Please wait for the current operation to finish');return false;}
    if(!editor.getState().dirty)return true;
    return new Promise(resolve=>{
      showModal('Keep your changes?',`<p class="modal-note" style="font-size:12px;color:#c1b4cd;margin:0">${escapeHTML(editor.getState().name||'This document')} has unsaved changes. Save a project first if you want to keep working on these layers later.</p>`,[{label:'Keep editing',action:closeModal},{label:'Discard changes',primary:true,action:()=>{modalCancelCallback=null;closeModal();resolve(true);}}],{subtitle:'Starting another document will replace this canvas.',onClose:()=>resolve(false)});
    });
  }
  async function receiveImage(payload) {
    if(editor.busy||loadBusy){toast('Please wait for the current operation to finish');return false;}
    if(!payload.place && !await confirmReplace())return false;
    if(editor.busy||loadBusy)return false;
    loadBusy=true;
    try {
      await(payload.place?editor.addImage(payload.dataURL,payload.name):editor.loadImage(payload.dataURL,payload.name));
      if(!payload.place)bridge({action:'documentReplaced'});
      toast(payload.place?'Image added as a layer':'Image opened');return true;
    }catch(error){toast(error.message||'Could not open image');return false;}
    finally{loadBusy=false;sync();}
  }
  async function receiveProject(payload) {
    if(editor.busy||loadBusy){toast('Please wait for the current operation to finish');return false;}
    if(!await confirmReplace())return false;
    if(editor.busy||loadBusy)return false;
    loadBusy=true;
    try{await editor.loadProject(payload.json);editor.markSaved?.();lastSavedName=payload.name;bridge({action:'documentReplaced'});toast('Project opened');return true;}
    catch(error){toast(error.message||'Could not open project');return false;}
    finally{loadBusy=false;sync();}
  }
  const cancel={label:'Cancel',action:closeModal};
  const clamp=(v,min,max)=>Math.min(max,Math.max(min,Number.isFinite(v)?v:min));
  function newDocument() {
    showModal('A fresh canvas',`<div class="preset-grid"><button class="preset-button active" data-preset="1600,1000">${svg('monitor')}<span>Landscape</span><small>1600 × 1000 px</small></button><button class="preset-button" data-preset="1080,1080">${svg('square')}<span>Square</span><small>1080 × 1080 px</small></button><button class="preset-button" data-preset="1080,1920">${svg('portrait')}<span>Portrait</span><small>1080 × 1920 px</small></button></div><div class="form-row"><label class="form-field"><span>Name</span><input id="newName" type="text" value="Untitled"></label></div><div class="form-row"><label class="form-field"><span>Width · px</span><input id="newWidth" type="number" min="1" max="8192" value="1600"></label><label class="form-field"><span>Height · px</span><input id="newHeight" type="number" min="1" max="8192" value="1000"></label></div><p class="modal-note">A clean white canvas, ready for your next idea.<br>Up to 8,192 px per side and 32 million pixels. Larger canvases support fewer layers.</p>`,[cancel,{label:'Create document',primary:true,action:async()=>{const w=+$('#newWidth').value,h=+$('#newHeight').value,name=$('#newName').value.trim()||'Untitled';if(!validSize(w,h))return;if(!await confirmReplace())return;if(editor.busy||loadBusy)return;editor.newDocument(w,h,name);bridge({action:'documentReplaced'});closeModal();toast('Your canvas is ready');}}],{subtitle:'Give your next idea a little space.'});
    $$('[data-preset]').forEach(button=>button.onclick=()=>{$$('.preset-button').forEach(el=>el.classList.remove('active'));button.classList.add('active');const[w,h]=button.dataset.preset.split(',');$('#newWidth').value=w;$('#newHeight').value=h;});
  }
  function validSize(w,h) { if(!Number.isInteger(w)||!Number.isInteger(h)||w<1||h<1||w>8192||h>8192||w*h>32000000){toast('Use 1–8192 px per side, up to 32 million pixels.');return false;}return true; }
  function resizeDocument() {
    showModal('Image size',`<div class="form-row"><label class="form-field"><span>Width · px</span><input id="resizeWidth" type="number" min="1" max="8192" value="${state.width}"></label><label class="form-field"><span>Height · px</span><input id="resizeHeight" type="number" min="1" max="8192" value="${state.height}"></label></div><label class="modal-checkbox"><input id="lockRatio" type="checkbox" checked> Keep proportions</label><p class="modal-note">Resizes all layers and the canvas. You can undo this change.<br>Up to 8,192 px per side and 32 million pixels, within the layer memory limit.</p>`,[cancel,{label:'Resize image',primary:true,action:()=>{const w=+$('#resizeWidth').value,h=+$('#resizeHeight').value;if(!validSize(w,h))return;editor.resizeDocument(w,h);closeModal();}}]);
    const ratio=state.width/state.height; $('#resizeWidth').oninput=()=>{if($('#lockRatio').checked)$('#resizeHeight').value=Math.round(+$('#resizeWidth').value/ratio);};$('#resizeHeight').oninput=()=>{if($('#lockRatio').checked)$('#resizeWidth').value=Math.round(+$('#resizeHeight').value*ratio);};
  }
  function exportDocument() {
    const baseName=(state.name||'Untitled').replace(/\.(prism|png|jpe?g|webp)$/i,'');
    showModal('Ready to share',`<div class="form-row"><label class="form-field"><span>File name</span><input id="exportName" type="text" value="${escapeHTML(baseName)}"></label></div><div class="form-row"><label class="form-field"><span>Format</span><select id="exportFormat"><option value="png">PNG · Keep transparency</option><option value="jpeg">JPEG · Smaller file</option></select></label><label class="form-field" id="qualityField" style="opacity:.4"><span>JPEG quality</span><select id="exportQuality" disabled><option value=".95">High · 95%</option><option value=".85">Balanced · 85%</option><option value=".65">Small · 65%</option><option value="1">Maximum · 100%</option></select></label></div><p class="modal-note">${state.width.toLocaleString()} × ${state.height.toLocaleString()} pixels · sRGB<br>JPEG uses a white background for transparent areas.</p>`,[cancel,{label:'Export image',primary:true,action:()=>{const format=$('#exportFormat').value,name=($('#exportName').value.trim()||baseName)+'.'+(format==='jpeg'?'jpg':'png'),dataURL=editor.exportImage(format,+$('#exportQuality').value);if(native)bridge({action:'export',dataURL,name});else download(dataURL,name);closeModal();toast(native?'Choose where to save your image':'Your image is ready');}}],{subtitle:'A finished image, wherever your work takes you.'});
    $('#exportFormat').onchange=()=>{const jpeg=$('#exportFormat').value==='jpeg';$('#exportQuality').disabled=!jpeg;$('#qualityField').style.opacity=jpeg?'1':'.4';};
  }
  function filterDialog(name) {
    const specs={brightness:['Brightness',-100,100,0,''],contrast:['Contrast',-100,100,0,''],saturation:['Saturation',-100,100,0,''],hue:['Hue',-180,180,0,'°'],blur:['Gaussian blur',0,40,4,' px'],sharpen:['Sharpen',0,3,1,'']};
    const [title,min,max,initial,unit]=specs[name],step=name==='sharpen'?'.1':'1';
    showModal(title,`<div style="display:flex"><span class="field-label">Amount</span><span id="filterValue" class="filter-value">${initial}${unit}</span></div><input id="filterRange" type="range" class="filter-range" min="${min}" max="${max}" value="${initial}" step="${step}"><div style="display:flex;justify-content:space-between;color:#776982;font-size:9px"><span>${min}${unit}</span><span>${max}${unit}</span></div><p class="modal-note" style="margin-top:20px">Applies to the selected layer. Every change can be undone.</p>`,[cancel,{label:`Apply ${title.toLowerCase()}`,primary:true,action:()=>{const amount=+$('#filterRange').value;editor.applyFilter(name,amount);closeModal();}}]);
    $('#filterRange').oninput=event=>$('#filterValue').textContent=event.target.value+unit;
  }
  function addText(position) {
    showModal('Say something',`<div class="form-row"><label class="form-field"><span>Your text</span><textarea id="textContent" placeholder="A few words can change everything."></textarea></label></div><div class="form-row"><label class="form-field"><span>Size · px</span><input id="modalTextSize" type="number" min="6" max="800" value="${textSize}"></label><label class="form-field"><span>Weight</span><select id="textWeight"><option value="400">Regular</option><option value="600">Semibold</option><option value="700">Bold</option></select></label></div><p class="modal-note">Text is rendered into its own movable layer.</p>`,[cancel,{label:'Add text',primary:true,action:()=>{const text=$('#textContent').value;if(!text.trim()){toast('Add a little text first');return;}textSize=clamp(+$('#modalTextSize').value,6,800);editor.addText(text,{...position,size:textSize,fontFamily:textFont,fontWeight:$('#textWeight').value});closeModal();}}]);
  }
  function zoomDialog() {
    showModal('A closer look',`<div class="form-row"><label class="form-field"><span>Zoom · percent</span><input id="zoomInput" type="number" min="3" max="800" value="${Math.round(state.zoom*100)}"></label></div>`,[cancel,{label:'Set zoom',primary:true,action:()=>{editor.setZoom(clamp(+$('#zoomInput').value,3,800)/100);closeModal();}}]);
  }
  function help() {
    const shortcuts=[['New document','⌘N'],['Open image / project','⌘O'],['Save project','⌘S'],['Export image','⇧⌘E'],['Undo / Redo','⌘Z / ⇧⌘Z'],['Duplicate layer','⌘J'],['Select all / Deselect','⌘A / ⌘D'],['Fit / Actual size','⌘0 / ⌘1'],['Brush / Eraser','B / E'],['Move / Selection','V / M'],['Crop / Text','C / T'],['Fill / Eyedropper','G / I'],['Shapes','U / ⇧U'],['Hand / Zoom','H / Z'],['Swap / Default colors','X / D'],['Brush size','[ / ]']];
    showModal('Make yourself at home',`<div class="shortcut-grid">${shortcuts.map(([label,key])=>`<div class="shortcut-row"><span>${label}</span><kbd>${key}</kbd></div>`).join('')}</div><div class="help-section"><strong>A few helpful gestures</strong><br>Hold Space and drag to pan. Scroll to zoom. Hold Option with the brush to pick a color. Drag layers to reorder them; double-click a layer name to rename it.<br><br>Save a <strong>.prism project</strong> to keep your layers. Export PNG for transparency or JPEG to share. Text and shapes become pixel layers. Prism does not open Photoshop PSD files.</div><div class="help-version">PRISM FOR MAC · 1.0</div>`,[{label:'Got it',primary:true,action:closeModal}],{wide:true,subtitle:'A focused image editor, with familiar tools and room to explore.'});
  }
  function about() { showModal('Prism',`<div style="display:flex;align-items:center;gap:16px;padding:5px 0 20px"><div style="width:57px;height:57px;border-radius:13px;background:#6f5a85;color:#e6d7f3;display:flex;align-items:center;justify-content:center">${svg('image')}</div><div><div style="font-size:18px;color:#e2d8ed;letter-spacing:-.4px">A little room to create.</div><div style="color:#8d7e9a;margin-top:6px;font-size:10px">Prism for Mac · Version 1.0</div></div></div><p class="modal-note">An independent, local image editor with layers, painting, selections, shapes, adjustments, and a canvas for your ideas.<br><br>Your images are edited on this Mac. Prism is independent software and is not affiliated with Adobe.</p>`,[{label:'Keyboard shortcuts',action:help},{label:'Done',primary:true,action:closeModal}]); }

  function download(dataURL,name) { const a=document.createElement('a');a.href=dataURL;a.download=name;document.body.append(a);a.click();a.remove(); }
  function saveProject(saveAs=false) {
    const data=editor.serializeProject(),name=(state.name||'Untitled').replace(/\.(prism|png|jpe?g|webp)$/i,'')+'.prism';
    if(native)bridge({action:'saveProject',data,name,saveAs});
    else{const url=URL.createObjectURL(new Blob([data],{type:'application/json'}));download(url,name);setTimeout(()=>URL.revokeObjectURL(url),1000);editor.markSaved?.();toast('Project saved with all your layers');}
  }
  async function readFile(file,place=false) {
    try {
      if(!file)return;
      if(file.name.toLowerCase().endsWith('.prism')||file.type==='application/json') {await receiveProject({name:file.name,json:await file.text()});}
      else if(file.type.startsWith('image/')||/\.(png|jpe?g|webp|gif|bmp|tiff?)$/i.test(file.name)){const dataURL=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(file);});await receiveImage({dataURL,name:file.name,place});}
      else toast('Open an image or a .prism project');
    } catch(error){toast(`Could not open the file: ${error.message||error}`);}
  }
  async function copy(cut=false) {
    if(editor.copySelection){clipboard=editor.copySelection();if(!clipboard){toast('Select a visible layer to copy');return;}if(cut)editor.deleteSelected();toast(cut?'Pixels cut — ready to paste':'Pixels copied — ready to paste');}
    else{clipboard=editor.exportImage('png');if(cut)editor.deleteSelected();toast(cut?'Image cut — ready to paste':'Image copied — ready to paste');}
    if(navigator.clipboard?.write&&window.ClipboardItem){try{const blob=await(await fetch(clipboard)).blob();await navigator.clipboard.write([new ClipboardItem({'image/png':blob})]);}catch(_) {}}
  }
  async function paste() {
    if(clipboard){await editor.addImage(clipboard,'Pasted image');return;}
    if(navigator.clipboard?.read){try{for(const item of await navigator.clipboard.read()){const type=item.types.find(t=>t.startsWith('image/'));if(type){const blob=await item.getType(type);await readFile(new File([blob],'Pasted image.png',{type}),true);return;}}}catch(_){}}
    toast('Copy pixels in Prism first, or use File → Place image');
  }
  async function run(command) {
    if(!editor)return false;
    if((editor.busy||loadBusy)&&!['help','about','showLayers','showHistory'].includes(command)){toast('Please wait for the current operation to finish');return false;}
    if(isDisabled(command))return false;
    try {
      const layer=selectedLayer();
      switch(command) {
        case 'new':newDocument();break;
        case 'open':if(native)bridge({action:'open'});else $('#fileInput').click();break;
        case 'place':if(native)bridge({action:'place'});else $('#placeInput').click();break;
        case 'save':saveProject(false);break;case 'saveAs':saveProject(true);break;
        case 'export':exportDocument();break;
        case 'undo':await editor.undo();break;case 'redo':await editor.redo();break;
        case 'copy':await copy();break;case 'cut':await copy(true);break;case 'paste':await paste();break;
        case 'selectAll':editor.selectAll();break;case 'deselect':editor.clearSelection();break;
        case 'deleteSelected':editor.deleteSelected();break;
        case 'addLayer':editor.addLayer();setPanel('layers');break;
        case 'duplicate':editor.duplicateLayer();break;case 'deleteLayer':editor.deleteLayer();break;
        case 'renameLayer':setPanel('layers');renameLayer();break;
        case 'lockLayer':editor.updateLayer(layer.id,{locked:!layer.locked});break;
        case 'mergeDown':editor.mergeDown();break;case 'flatten':editor.flatten();break;
        case 'resize':resizeDocument();break;
        case 'rotateCW':editor.rotateDocument(90);break;case 'rotateCCW':editor.rotateDocument(-90);break;case 'rotate180':editor.rotateDocument(180);break;
        case 'flipHorizontal':editor.flipDocument('horizontal');break;case 'flipVertical':editor.flipDocument('vertical');break;
        case 'brightness':case 'contrast':case 'saturation':case 'hue':case 'blur':case 'sharpen':filterDialog(command);break;
        case 'grayscale':case 'sepia':case 'invert':editor.applyFilter(command,1);break;
        case 'zoomIn':editor.setZoom(state.zoom*1.25);break;case 'zoomOut':editor.setZoom(state.zoom/1.25);break;
        case 'fit':editor.fitToView();break;case 'actual':editor.setZoom(1);break;case 'zoom':zoomDialog();break;
        case 'showLayers':setPanel('layers');break;case 'showHistory':setPanel('history');break;
        case 'help':help();break;case 'about':about();break;
        default:return false;
      }
      return true;
    } catch(error){toast(error.message||String(error));console.error(error);return false;}
  }
  document.addEventListener('click',event=>{const button=event.target.closest('[data-command]');if(button&&!button.disabled)run(button.dataset.command);});
  document.addEventListener('pointerdown',event=>{if(liveMenu&&!event.target.closest('.dropdown-menu,.menu-trigger,#layerMenuButton,.layer-row'))closeMenu();});
  $('#layersTab').onclick=()=>setPanel('layers');$('#historyTab').onclick=()=>setPanel('history');
  $('#layerMenuButton').onclick=()=>openMenu('layerActions',$('#layerMenuButton'),menus.Layer);
  $('#blendMode').onchange=event=>{if(selectedLayer())editor.updateLayer(state.selectedLayerId,{blendMode:event.target.value});};
  $('#layerOpacity').onchange=event=>{if(selectedLayer())editor.updateLayer(state.selectedLayerId,{opacity:clamp(+event.target.value,0,100)/100});};
  $('#lockLayer').onclick=()=>run('lockLayer');$('#zoomRange').oninput=event=>editor.setZoom(+event.target.value/100);
  $('#navigatorPreview').ondblclick=()=>editor.fitToView();
  $('#fileInput').onchange=async event=>{await readFile(event.target.files[0]);event.target.value='';};
  $('#placeInput').onchange=async event=>{await readFile(event.target.files[0],true);event.target.value='';};
  let colorTarget='foreground';
  function chooseColor(target='foreground'){colorTarget=target;$('#nativeColorInput').value=target==='foreground'?state.color:state.secondaryColor;$('#nativeColorInput').click();}
  $('#foregroundSwatch').onclick=()=>chooseColor();$('#backgroundSwatch').onclick=()=>chooseColor('background');
  $('#nativeColorInput').oninput=event=>colorTarget==='foreground'?editor.setColor(event.target.value):editor.setSecondaryColor(event.target.value);
  $('#hexColorButton').onclick=()=>{
    showModal('Choose a color',`<div class="form-row"><label class="form-field"><span>Hex color</span><input id="hexEntry" type="text" value="${state.color}" maxlength="7" spellcheck="false"></label></div>`,[cancel,{label:'Use color',primary:true,action:()=>{const color=$('#hexEntry').value.trim();if(!/^#?([0-9a-f]{6}|[0-9a-f]{3})$/i.test(color)){toast('Enter a hex color, such as #E5B96F');return;}editor.setColor(color.startsWith('#')?color:'#'+color);closeModal();}}]);
  };
  function swapColors(){const old=state.color;editor.setColor(state.secondaryColor);editor.setSecondaryColor(old);}
  $('#swapColors').onclick=swapColors;$('#defaultColors').onclick=()=>{editor.setColor('#000000');editor.setSecondaryColor('#ffffff');};
  function hsvToHex(h,s,v){const f=n=>{const k=(n+h/60)%6;return v-v*s*Math.max(0,Math.min(k,4-k,1));};return'#'+[f(5),f(3),f(1)].map(x=>Math.round(x*255).toString(16).padStart(2,'0')).join('');}
  function hexToHSV(hex){hex=hex.replace('#','');if(hex.length===3)hex=hex.split('').map(x=>x+x).join('');const [r,g,b]=[0,2,4].map(i=>parseInt(hex.slice(i,i+2),16)/255),max=Math.max(r,g,b),min=Math.min(r,g,b),d=max-min;let h=hue;if(d){if(max===r)h=((g-b)/d)%6;else if(max===g)h=(b-r)/d+2;else h=(r-g)/d+4;h=(h*60+360)%360;}return{h,s:max?d/max:0,v:max};}
  function updateColorField(){$('#colorField').style.background=hsvToHex(hue,1,1);$('#hueSlider').value=hue;$('#colorCursor').style.left=saturation*100+'%';$('#colorCursor').style.top=(1-value)*100+'%';}
  $('#hueSlider').oninput=event=>{hue=+event.target.value;editor.setColor(hsvToHex(hue,saturation,value));};
  let choosingColor=false;
  function colorPoint(event){const rect=$('#colorField').getBoundingClientRect();saturation=clamp((event.clientX-rect.left)/rect.width,0,1);value=1-clamp((event.clientY-rect.top)/rect.height,0,1);editor.setColor(hsvToHex(hue,saturation,value));}
  $('#colorField').onpointerdown=event=>{choosingColor=true;event.currentTarget.setPointerCapture(event.pointerId);colorPoint(event);};
  $('#colorField').onpointermove=event=>{if(choosingColor)colorPoint(event);};$('#colorField').onpointerup=()=>choosingColor=false;
  document.addEventListener('keydown',event=>{
    const typing=/INPUT|TEXTAREA|SELECT/.test(event.target.tagName)||event.target.isContentEditable;
    if(event.key==='Escape'){if($('#modalRoot').children.length)closeModal();else if(liveMenu)closeMenu();else editor?.clearSelection();return;}
    if($('#modalRoot').children.length){if(event.key==='Enter'&&event.target.tagName!=='TEXTAREA'){event.preventDefault();$('.modal-button.primary')?.click();}return;}
    if(typing)return;
    if(event.metaKey||event.ctrlKey){
      if(native)return;
      const key=event.key.toLowerCase();let command;
      if(key==='n')command=event.shiftKey?'addLayer':'new';else if(key==='o')command='open';else if(key==='s')command=event.shiftKey?'saveAs':'save';else if(key==='e'&&event.shiftKey)command='export';else if(key==='z')command=event.shiftKey?'redo':'undo';else if(key==='a')command='selectAll';else if(key==='d')command='deselect';else if(key==='j')command='duplicate';else if(key==='c')command='copy';else if(key==='x')command='cut';else if(key==='v')command='paste';else if(key==='0')command='fit';else if(key==='1')command='actual';else if(key==='='||key==='+')command='zoomIn';else if(key==='-')command='zoomOut';
      if(command){event.preventDefault();run(command);}return;
    }
    if(event.altKey)return;
    const key=event.key.toLowerCase(),map={v:'move',m:'marquee',b:'brush',e:'eraser',u:event.shiftKey?'ellipse':'rectangle',g:'fill',i:'eyedropper',t:'text',c:'crop',h:'hand',z:'zoom'};
    if(map[key]){event.preventDefault();editor.setTool(map[key]);}
    else if(key==='x')swapColors();else if(key==='d')$('#defaultColors').click();else if(key==='[')editor.setBrushSize(Math.max(1,state.brushSize-5));else if(key===']')editor.setBrushSize(Math.min(500,state.brushSize+5));else if(event.key==='Backspace'||event.key==='Delete'){event.preventDefault();run('deleteSelected');}
  });
  const workspace=$('#workspace');
  workspace.addEventListener('dragover',event=>{event.preventDefault();event.dataTransfer.dropEffect='copy';});
  workspace.addEventListener('drop',async event=>{event.preventDefault();const files=[...event.dataTransfer.files];for(const file of files)await readFile(file,true);});
  document.addEventListener('contextmenu',event=>{if(!event.target.closest('input,textarea,.layer-row'))event.preventDefault();});
  window.PrismApp = {
    command:run,
    receiveFile:receiveImage,
    receivePlacedFile:payload=>receiveImage({...payload,place:true}),
    receiveProject,
    didSave:name=>{lastSavedName=name;editor.markSaved?.();toast('Project saved with all your layers');},
    didExport:name=>toast(`${name || 'Image'} exported`),
    markSaved:()=>editor.markSaved?.(),
    notify:toast,
    getState:()=>editor?.getState(),
    editor:null
  };
  try {
    editor=new window.PrismEditor($('#editorCanvas'),workspace);window.PrismApp.editor=editor;
    editor.on('change',sync);editor.on('textrequest',addText);editor.on('notice',toast);editor.on('error',toast);sync();bridge({action:'ready'});
  } catch(error){console.error(error);toast('The editor could not start: '+error.message);}
})();
