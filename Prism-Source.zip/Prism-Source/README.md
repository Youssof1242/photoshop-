# Prism for Mac

A standalone, offline photo editor for macOS 12 or later. The app includes a native AppKit window, macOS menus and file dialogs, and an original layer-based canvas editor bundled inside WebKit. No browser, server, account, subscription, or network connection is required.

## Build

On a Mac with Xcode or compatible Swift developer tools installed:

```sh
bash build.sh /absolute/path/to/Prism.app
```

The script compiles both Apple silicon and Intel binaries, combines them into a universal executable, copies local editor assets, and applies an ad hoc code signature. An Apple Developer ID certificate and notarization are not included.

## Files

- `native/main.swift`: Mac application, menus, file association, file dialogs, orientation-aware image import, atomic project saves, and unsaved-change prompts.
- `native/Info.plist`: Application and `.prism` document metadata.
- `web/editor.js`: Layer canvas model, drawing tools, filters, transforms, history, and project serialization.
- `web/ui.js`, `web/index.html`, `web/styles.css`: Offline workspace interface.
- `assets/`: Original Prism icon.
- `tests/editor-test.js`: Functional checks run inside the actual WKWebView renderer.

## Verify

After building, run the application binary with these environment variables:

```sh
PRISM_TEST_SCRIPT="$PWD/tests/editor-test.js" \
PRISM_TEST_RESULT="$PWD/test-result.json" \
PRISM_SCREENSHOT="$PWD/preview.png" \
/absolute/path/to/Prism.app/Contents/MacOS/Prism
```

The test harness exercises real canvas pixels and document operations, writes the report and screenshot, and closes the test application. Normal launches do not run tests.

For an offline engine check without a desktop window, install `@napi-rs/canvas` in a Node environment and run `node tests/engine-test.cjs`. Run `node tests/ui-smoke-test.cjs` for the interface callback checks, which use a small DOM and editor mock. These checks complement rather than replace running the app on a normal Mac desktop. See `VALIDATION.md` for this build's results.

Prism is an independent simplified editor. Photoshop PSD compatibility, camera RAW development, Adobe plug-ins, vector text editing, layer masks, and Photoshop's full advanced feature set are outside its current scope. The `.prism` format preserves raster layers and document properties; undo history is session-only.
