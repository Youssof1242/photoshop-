import AppKit
import WebKit
import UniformTypeIdentifiers
import ImageIO

// Prism is a standalone, offline macOS application. Its editor is bundled locally.
final class AppDelegate: NSObject, NSApplicationDelegate, NSWindowDelegate, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate {
    var window: NSWindow!
    var webView: WKWebView!
    var ready = false
    var dirty = false
    var documentBusy = false
    var documentName = "Untitled"
    var projectURL: URL?
    var pendingFiles: [URL] = []
    var closeAfterSave = false
    var quitAfterSave = false
    var commandItems: [NSMenuItem] = []
    var selfTestStarted = false
    var fileInFlight = false
    let testScript = ProcessInfo.processInfo.environment["PRISM_TEST_SCRIPT"]

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.regular)
        NSApp.appearance = NSAppearance(named: .darkAqua)
        buildMenus()
        let configuration = WKWebViewConfiguration()
        configuration.userContentController.add(self, name: "prism")
        configuration.userContentController.addUserScript(WKUserScript(source: "window.PRISM_NATIVE = true;", injectionTime: .atDocumentStart, forMainFrameOnly: true))
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = false
        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.underPageBackgroundColor = NSColor(calibratedWhite: 0.11, alpha: 1)
        webView.allowsBackForwardNavigationGestures = false
        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1440, height: 920), styleMask: [.titled, .closable, .miniaturizable, .resizable], backing: .buffered, defer: false)
        window.title = "Prism"
        window.minSize = NSSize(width: 1000, height: 660)
        window.backgroundColor = NSColor(calibratedWhite: 0.11, alpha: 1)
        window.contentView = webView
        window.delegate = self
        window.tabbingMode = .disallowed
        window.collectionBehavior = [.fullScreenPrimary]
        window.setFrameAutosaveName("PrismMainWindow")
        window.center()
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        guard let resources = Bundle.main.resourceURL else { fatalError("Application resources missing") }
        let directory = resources.appendingPathComponent("web")
        webView.loadFileURL(directory.appendingPathComponent("index.html"), allowingReadAccessTo: directory)
    }

    func buildMenus() {
        let main = NSMenu()
        NSApp.mainMenu = main
        func menu(_ title: String) -> NSMenu {
            let entry = NSMenuItem(title: title, action: nil, keyEquivalent: "")
            let submenu = NSMenu(title: title)
            entry.submenu = submenu
            main.addItem(entry)
            return submenu
        }
        func command(_ parent: NSMenu, _ title: String, _ name: String, _ key: String = "", _ modifiers: NSEvent.ModifierFlags = [.command]) {
            let item = NSMenuItem(title: title, action: #selector(menuCommand(_:)), keyEquivalent: key)
            item.keyEquivalentModifierMask = modifiers
            item.representedObject = name
            item.target = self
            parent.addItem(item)
            commandItems.append(item)
        }
        let app = menu("Prism")
        let about = NSMenuItem(title: "About Prism", action: #selector(showAbout), keyEquivalent: "")
        about.target = self
        app.addItem(about)
        app.addItem(.separator())
        let services = NSMenuItem(title: "Services", action: nil, keyEquivalent: "")
        services.submenu = NSMenu(title: "Services")
        app.addItem(services)
        NSApp.servicesMenu = services.submenu
        app.addItem(.separator())
        app.addItem(withTitle: "Hide Prism", action: #selector(NSApplication.hide(_:)), keyEquivalent: "h")
        let hideOthers = app.addItem(withTitle: "Hide Others", action: #selector(NSApplication.hideOtherApplications(_:)), keyEquivalent: "h")
        hideOthers.keyEquivalentModifierMask = [.command, .option]
        app.addItem(withTitle: "Show All", action: #selector(NSApplication.unhideAllApplications(_:)), keyEquivalent: "")
        app.addItem(.separator())
        app.addItem(withTitle: "Quit Prism", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        let file = menu("File")
        command(file, "New…", "new", "n")
        command(file, "Open…", "open", "o")
        command(file, "Place Image as Layer…", "place", "o", [.command, .shift])
        file.addItem(.separator())
        command(file, "Save Project", "save", "s")
        command(file, "Save Project As…", "saveAs", "s", [.command, .shift])
        command(file, "Export Image…", "export", "e", [.command, .shift])
        file.addItem(.separator())
        file.addItem(withTitle: "Close Window", action: #selector(NSWindow.performClose(_:)), keyEquivalent: "w")
        let edit = menu("Edit")
        command(edit, "Undo", "undo", "z")
        command(edit, "Redo", "redo", "z", [.command, .shift])
        edit.addItem(.separator())
        command(edit, "Cut", "cut", "x")
        command(edit, "Copy", "copy", "c")
        command(edit, "Paste", "paste", "v")
        edit.addItem(.separator())
        command(edit, "Delete Contents", "deleteSelected")
        let image = menu("Image")
        command(image, "Image Size…", "resize")
        command(image, "Rotate 90° Clockwise", "rotateCW")
        command(image, "Rotate 90° Counterclockwise", "rotateCCW")
        command(image, "Flip Horizontal", "flipHorizontal")
        command(image, "Flip Vertical", "flipVertical")
        let layer = menu("Layer")
        command(layer, "New Layer", "addLayer", "n", [.command, .shift])
        command(layer, "Duplicate Layer", "duplicate", "j")
        command(layer, "Delete Layer", "deleteLayer")
        layer.addItem(.separator())
        command(layer, "Merge Down", "mergeDown", "e")
        command(layer, "Flatten Image", "flatten")
        let selection = menu("Select")
        command(selection, "Select All", "selectAll", "a")
        command(selection, "Deselect", "deselect", "d")
        let filter = menu("Filter")
        command(filter, "Brightness…", "brightness")
        command(filter, "Contrast…", "contrast")
        command(filter, "Hue…", "hue")
        command(filter, "Saturation…", "saturation")
        command(filter, "Gaussian Blur…", "blur")
        filter.addItem(.separator())
        command(filter, "Grayscale", "grayscale")
        command(filter, "Sepia", "sepia")
        command(filter, "Invert", "invert")
        command(filter, "Sharpen", "sharpen")
        let view = menu("View")
        command(view, "Zoom In", "zoomIn", "=")
        command(view, "Zoom Out", "zoomOut", "-")
        command(view, "Fit on Screen", "fit", "0")
        command(view, "Actual Size", "actual", "1")
        view.addItem(.separator())
        let fullscreen = view.addItem(withTitle: "Enter Full Screen", action: #selector(NSWindow.toggleFullScreen(_:)), keyEquivalent: "f")
        fullscreen.keyEquivalentModifierMask = [.command, .control]
        let windows = menu("Window")
        windows.addItem(withTitle: "Minimize", action: #selector(NSWindow.performMiniaturize(_:)), keyEquivalent: "m")
        windows.addItem(withTitle: "Zoom", action: #selector(NSWindow.performZoom(_:)), keyEquivalent: "")
        NSApp.windowsMenu = windows
        let help = menu("Help")
        command(help, "Prism Help & Keyboard Shortcuts", "help", "?")
        NSApp.helpMenu = help
    }

    @objc func menuCommand(_ sender: NSMenuItem) {
        guard let command = sender.representedObject as? String, ready else { return }
        runCommand(command)
    }

    func runCommand(_ command: String) {
        if ["undo", "redo", "cut", "copy", "paste", "selectAll"].contains(command) {
            webView.evaluateJavaScript("!!(document.activeElement && (document.activeElement.matches('input,textarea,select') || document.activeElement.isContentEditable))") { value, _ in
                if value as? Bool == true {
                    NSApp.sendAction(NSSelectorFromString(command + ":"), to: nil, from: self)
                } else { self.evaluate("void (window.PrismApp && window.PrismApp.command(\(self.jsString(command))))") }
            }
            return
        }
        evaluate("void (window.PrismApp && window.PrismApp.command(\(jsString(command))))")
    }

    @objc func showAbout() {
        NSApp.orderFrontStandardAboutPanel(options: [.applicationName: "Prism", .applicationVersion: "1.0", .version: "1", .credits: NSAttributedString(string: "An independent, offline photo editor for Mac.\nLayers, brushes, adjustments, and a little light.\n\nPrism is not affiliated with Adobe.")])
    }

    func jsString(_ string: String) -> String {
        let data = try! JSONSerialization.data(withJSONObject: [string], options: [.fragmentsAllowed])
        let array = String(data: data, encoding: .utf8)!
        return String(array.dropFirst().dropLast())
    }

    func evaluate(_ script: String) {
        webView?.evaluateJavaScript(script) { _, error in
            if let error = error { NSLog("Prism: %@", error.localizedDescription) }
        }
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.frameInfo.isMainFrame, let body = message.body as? [String: Any], let action = body["action"] as? String else { return }
        switch action {
        case "ready":
            ready = true
            let files = pendingFiles
            pendingFiles = []
            for file in files.prefix(1) { openFile(file, place: false) }
            startSelfTestIfNeeded()
        case "state":
            dirty = body["dirty"] as? Bool ?? false
            documentBusy = body["busy"] as? Bool ?? false
            documentName = body["name"] as? String ?? "Untitled"
            window.title = "\(documentName) — Prism"
            window.isDocumentEdited = dirty
        case "open": openPanel(place: false)
        case "place": openPanel(place: true)
        case "saveProject":
            guard let value = body["data"] else { return }
            let data: Data?
            if let string = value as? String { data = string.data(using: .utf8) }
            else { data = try? JSONSerialization.data(withJSONObject: value) }
            if let data = data { saveProject(data, name: body["name"] as? String ?? documentName, saveAs: body["saveAs"] as? Bool ?? false) }
        case "export":
            guard let dataURL = body["dataURL"] as? String, let split = dataURL.firstIndex(of: ","), let data = Data(base64Encoded: String(dataURL[dataURL.index(after: split)...])) else { showError("The image could not be exported."); return }
            exportImage(data, name: body["name"] as? String ?? "\(documentName).png", jpeg: dataURL.hasPrefix("data:image/jpeg"))
        case "newDocument", "documentReplaced": projectURL = nil
        case "log": if let text = body["message"] as? String { NSLog("Prism editor: %@", text) }
        default: break
        }
    }

    func openPanel(place: Bool) {
        guard !fileInFlight else { return }
        let panel = NSOpenPanel()
        panel.title = place ? "Place Image as Layer" : "Open Image or Prism Project"
        panel.message = place ? "The image will become a new editable layer." : "Open an image, or continue a saved .prism project."
        panel.canChooseDirectories = false
        panel.allowsMultipleSelection = false
        let project = UTType(filenameExtension: "prism") ?? .json
        panel.allowedContentTypes = place ? [.image] : [.image, project, .json]
        panel.beginSheetModal(for: window) { response in
            if response == .OK, let url = panel.url { self.openFile(url, place: place) }
        }
    }

    func openFile(_ url: URL, place: Bool) {
        if !ready { pendingFiles = [url]; return }
        guard !fileInFlight else { return }
        fileInFlight = true
        do {
            let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
            guard (attributes[.size] as? NSNumber)?.int64Value ?? 0 < 512 * 1024 * 1024 else { throw PrismError.message("This file is too large. Try an image or project smaller than 512 MB.") }
            let name = url.deletingPathExtension().lastPathComponent
            if ["prism", "json"].contains(url.pathExtension.lowercased()) {
                guard !place else { throw PrismError.message("Choose an image to place as a layer.") }
                let data = try Data(contentsOf: url)
                guard let json = String(data: data, encoding: .utf8) else { throw PrismError.message("This project is not a valid text file.") }
                let payload: [String: Any] = ["name": name, "json": json]
                let encoded = try JSONSerialization.data(withJSONObject: payload)
                let script = "return await window.PrismApp.receiveProject(\(String(data: encoded, encoding: .utf8)!))"
                webView.callAsyncJavaScript(script, arguments: [:], in: nil, in: .page) { result in
                    self.fileInFlight = false
                    switch result {
                    case .failure(let error): self.showError(error.localizedDescription)
                    case .success(let value): if (value as? Bool) == true { self.projectURL = url; NSDocumentController.shared.noteNewRecentDocumentURL(url) }
                    }
                }
            } else {
                let dataURL = try imageDataURL(url)
                let payload: [String: Any] = ["name": name, "dataURL": dataURL, "place": place]
                let data = try JSONSerialization.data(withJSONObject: payload)
                webView.callAsyncJavaScript("return await window.PrismApp.receiveFile(\(String(data: data, encoding: .utf8)!))", arguments: [:], in: nil, in: .page) { result in
                    self.fileInFlight = false
                    switch result {
                    case .failure(let error): self.showError(error.localizedDescription)
                    case .success(let value): if (value as? Bool) == true {
                            if !place { self.projectURL = nil }
                            NSDocumentController.shared.noteNewRecentDocumentURL(url)
                        }
                    }
                }
            }
        } catch { fileInFlight = false; showError(error.localizedDescription) }
    }

    func imageDataURL(_ url: URL) throws -> String {
        guard let source = CGImageSourceCreateWithURL(url as CFURL, nil), let props = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [CFString: Any], let width = props[kCGImagePropertyPixelWidth] as? Int, let height = props[kCGImagePropertyPixelHeight] as? Int else {
            throw PrismError.message("This image format could not be read. Try PNG, JPEG, TIFF, or HEIC.")
        }
        guard width > 0, height > 0, width <= 8192, height <= 8192, width * height <= 32_000_000 else { throw PrismError.message("Choose an image up to 8,192 pixels per side and 32 megapixels.") }
        let options: [CFString: Any] = [kCGImageSourceCreateThumbnailFromImageAlways: true, kCGImageSourceCreateThumbnailWithTransform: true, kCGImageSourceThumbnailMaxPixelSize: max(width, height)]
        guard let image = CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary) else { throw PrismError.message("The image could not be decoded.") }
        let data = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(data, UTType.png.identifier as CFString, 1, nil) else { throw PrismError.message("The image could not be converted.") }
        CGImageDestinationAddImage(destination, image, nil)
        guard CGImageDestinationFinalize(destination) else { throw PrismError.message("The image could not be read.") }
        return "data:image/png;base64," + (data as Data).base64EncodedString()
    }

    func saveProject(_ data: Data, name: String, saveAs: Bool) {
        if let url = projectURL, !saveAs { writeProject(data, to: url); return }
        let panel = NSSavePanel()
        panel.title = "Save Prism Project"
        panel.nameFieldStringValue = safeFileName(name, extension: "prism")
        panel.allowedContentTypes = [UTType(filenameExtension: "prism") ?? .json]
        panel.canCreateDirectories = true
        panel.beginSheetModal(for: window) { response in
            if response == .OK, let url = panel.url { self.writeProject(data, to: url) }
            else { self.cancelPendingClose() }
        }
    }

    func safeFileName(_ name: String, extension ext: String) -> String {
        var base = (name as NSString).lastPathComponent
        for ending in [".prism", ".png", ".jpg", ".jpeg", ".webp", ".tiff", ".heic"] where base.lowercased().hasSuffix(ending) { base = String(base.dropLast(ending.count)) }
        return (base.isEmpty ? "Untitled" : base) + "." + ext
    }

    func writeProject(_ data: Data, to url: URL) {
        do {
            try data.write(to: url, options: .atomic)
            projectURL = url
            dirty = false
            window.isDocumentEdited = false
            NSDocumentController.shared.noteNewRecentDocumentURL(url)
            evaluate("window.PrismApp.didSave && window.PrismApp.didSave(\(jsString(url.deletingPathExtension().lastPathComponent)))")
            if quitAfterSave { quitAfterSave = false; NSApp.reply(toApplicationShouldTerminate: true) }
            if closeAfterSave { closeAfterSave = false; window.close() }
        } catch { cancelPendingClose(); showError("The project could not be saved. \(error.localizedDescription)") }
    }

    func exportImage(_ data: Data, name: String, jpeg: Bool) {
        let panel = NSSavePanel()
        panel.title = "Export Image"
        panel.nameFieldStringValue = safeFileName(name, extension: jpeg ? "jpg" : "png")
        panel.allowedContentTypes = [jpeg ? .jpeg : .png]
        panel.canCreateDirectories = true
        panel.beginSheetModal(for: window) { response in
            guard response == .OK, let url = panel.url else { return }
            do {
                try data.write(to: url, options: .atomic)
                self.evaluate("window.PrismApp.didExport && window.PrismApp.didExport(\(self.jsString(url.lastPathComponent)))")
            } catch { self.showError("The image could not be saved. \(error.localizedDescription)") }
        }
    }

    func confirmClose() -> NSApplication.ModalResponse {
        let alert = NSAlert()
        alert.messageText = "Save changes to \(documentName)?"
        alert.informativeText = "Save a Prism project to keep your layers and continue editing later."
        alert.addButton(withTitle: "Save Project")
        alert.addButton(withTitle: "Discard Changes")
        alert.addButton(withTitle: "Cancel")
        return alert.runModal()
    }

    func windowShouldClose(_ sender: NSWindow) -> Bool {
        guard !documentBusy && !fileInFlight else {
            evaluate("window.PrismApp.notify('Please wait for the current operation to finish, then close the window.')")
            return false
        }
        guard dirty else { return true }
        switch confirmClose() {
        case .alertFirstButtonReturn: closeAfterSave = true; saveBeforeClosing(); return false
        case .alertSecondButtonReturn: dirty = false; return true
        default: return false
        }
    }

    func cancelPendingClose() {
        closeAfterSave = false
        if quitAfterSave { quitAfterSave = false; NSApp.reply(toApplicationShouldTerminate: false) }
    }

    func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply {
        guard !documentBusy && !fileInFlight else {
            evaluate("window.PrismApp.notify('Please wait for the current operation to finish, then quit Prism.')")
            return .terminateCancel
        }
        guard dirty else { return .terminateNow }
        switch confirmClose() {
        case .alertFirstButtonReturn: quitAfterSave = true; saveBeforeClosing(); return .terminateLater
        case .alertSecondButtonReturn: return .terminateNow
        default: return .terminateCancel
        }
    }

    func saveBeforeClosing() {
        webView.callAsyncJavaScript("return await window.PrismApp.command('save')", arguments: [:], in: nil, in: .page) { result in
            switch result {
            case .success(let value): if value as? Bool != true { self.cancelPendingClose() }
            case .failure: self.cancelPendingClose()
            }
        }
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { return true }
    func application(_ sender: NSApplication, openFiles filenames: [String]) {
        for path in filenames.prefix(1) { openFile(URL(fileURLWithPath: path), place: false) }
        sender.reply(toOpenOrPrint: .success)
    }

    func showError(_ message: String) {
        let alert = NSAlert()
        alert.alertStyle = .warning
        alert.messageText = "Prism couldn’t complete that action"
        alert.informativeText = message
        alert.addButton(withTitle: "OK")
        if let window = window { alert.beginSheetModal(for: window) }
        else { alert.runModal() }
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
        if url.isFileURL, let resources = Bundle.main.resourceURL, url.standardizedFileURL.path.hasPrefix(resources.standardizedFileURL.path + "/") { decisionHandler(.allow) }
        else if url.absoluteString == "about:blank" { decisionHandler(.allow) }
        else { decisionHandler(.cancel) }
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let alert = NSAlert(); alert.messageText = message; alert.addButton(withTitle: "OK")
        alert.beginSheetModal(for: window) { _ in completionHandler() }
    }
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let alert = NSAlert(); alert.messageText = message; alert.addButton(withTitle: "Continue"); alert.addButton(withTitle: "Cancel")
        alert.beginSheetModal(for: window) { completionHandler($0 == .alertFirstButtonReturn) }
    }
    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
        let alert = NSAlert(); alert.messageText = prompt; alert.addButton(withTitle: "OK"); alert.addButton(withTitle: "Cancel")
        let input = NSTextField(frame: NSRect(x: 0, y: 0, width: 280, height: 24)); input.stringValue = defaultText ?? ""; alert.accessoryView = input
        alert.beginSheetModal(for: window) { completionHandler($0 == .alertFirstButtonReturn ? input.stringValue : nil) }
    }
    func webView(_ webView: WKWebView, runOpenPanelWith parameters: WKOpenPanelParameters, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping ([URL]?) -> Void) {
        let panel = NSOpenPanel(); panel.allowsMultipleSelection = parameters.allowsMultipleSelection; panel.canChooseDirectories = false
        panel.beginSheetModal(for: window) { completionHandler($0 == .OK ? panel.urls : nil) }
    }

    // Runs the same editor in WebKit for repeatable release checks. Not used normally.
    func startSelfTestIfNeeded() {
        guard let path = testScript, !selfTestStarted else { return }
        selfTestStarted = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            do {
                let script = try String(contentsOfFile: path, encoding: .utf8)
                self.webView.callAsyncJavaScript(script, arguments: [:], in: nil, in: .page) { result in
                    let output: String
                    switch result {
                    case .success(let value):
                        if let object = value as? [String: Any], let data = try? JSONSerialization.data(withJSONObject: object, options: [.prettyPrinted, .sortedKeys]) { output = String(data: data, encoding: .utf8)! }
                        else { output = String(describing: value) }
                    case .failure(let error): output = "{\"error\":\(self.jsString(error.localizedDescription))}"
                    }
                    if let destination = ProcessInfo.processInfo.environment["PRISM_TEST_RESULT"] { try? output.write(toFile: destination, atomically: true, encoding: .utf8) }
                    print(output)
                    if let screenshotPath = ProcessInfo.processInfo.environment["PRISM_SCREENSHOT"] {
                        self.webView.takeSnapshot(with: nil) { image, _ in
                            if let image = image, let tiff = image.tiffRepresentation, let bitmap = NSBitmapImageRep(data: tiff), let png = bitmap.representation(using: .png, properties: [:]) { try? png.write(to: URL(fileURLWithPath: screenshotPath)) }
                            self.dirty = false
                            NSApp.terminate(nil)
                        }
                    } else { self.dirty = false; NSApp.terminate(nil) }
                }
            } catch { print(error); self.dirty = false; NSApp.terminate(nil) }
        }
    }
}

enum PrismError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case let .message(message) = self { return message }; return nil }
}

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.run()
