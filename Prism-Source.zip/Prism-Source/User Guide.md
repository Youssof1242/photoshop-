# Prism for Mac

Prism is a local photo and graphics editor with a familiar dark workspace. It is an original, simplified app and is not affiliated with Adobe.

## Get started

1. Open **Prism.app**. To keep it installed, move it to your Mac’s **Applications** folder.
2. Choose **File → New** to make a canvas, or **File → Open** to open an image or a saved Prism project.
3. Choose a tool from the left toolbar. The bar above the canvas shows its options. Use the right panel to select and manage layers.
4. Save an editable **.prism** project. Export a **PNG** or **JPEG** when you want an image to share.

Prism works locally; editing does not require an account or an internet connection.

## Editing

- **Move (V):** drag the selected layer to reposition it.
- **Marquee (M):** drag a rectangular selection. Use **Command D** to deselect.
- **Brush (B)** and **Eraser (E):** paint or erase on the selected layer. Adjust the tool options above the canvas.
- **Rectangle (U)** and **Ellipse:** drag to draw a shape. **Shift U** selects the ellipse tool.
- **Fill (G):** fill an area with the foreground color.
- **Eyedropper (I):** sample a color from your image. You can also hold **Option** while using the brush to sample.
- **Text (T):** add text using the available text options. Text becomes pixels when added; undo and add it again to change its wording.
- **Crop (C):** drag around the part of the image you want to keep. Releasing the mouse applies the crop; use Undo to restore the previous size.
- **Hand (H)** and **Zoom (Z):** move around the canvas and change the viewing scale. Hold **Space** and drag to pan; **Option** with the zoom tool zooms out.

Click the foreground color swatch to choose a color. Press **X** to swap foreground and background colors, or **D** to restore the defaults.

## Layers and adjustments

Select a layer before editing it. The Layers panel lets you work on separate parts of an image. The Layer menu includes adding, duplicating, merging, and flattening layers.

Use the **Image** menu to resize, rotate, or flip your image. The **Filter** menu includes brightness, contrast, saturation, hue, blur, grayscale, sepia, invert, and sharpen. Filters change the selected unlocked layer and respect a marquee selection. Duplicate a layer first if you want to keep the original. Keep an editable project before flattening or exporting.

## Save and export

**Save Project** stores an editable **.prism** file. Reopen it to continue working with its layers. Undo history is retained only during the current editing session.

**Export** creates a flattened **PNG** or **JPEG** image. Use PNG when you need transparency; JPEG places transparent areas on white. Exporting an image does not replace saving an editable project.

Documents support up to 8,192 pixels per side, 32 million pixels total, and 50 layers. A 64 million pixel layer budget may limit the layer count for larger images. Prism does not support Photoshop PSD documents, camera RAW development, Adobe plug-ins, or Photoshop’s full set of advanced tools.

## Useful shortcuts

| Action | Shortcut |
|---|---|
| New document | Command N |
| Open image or project | Command O |
| Save project | Command S |
| Save project as a new file | Command Shift S |
| Export image | Command Shift E |
| Undo / Redo | Command Z / Command Shift Z |
| Select all / Deselect | Command A / Command D |
| Duplicate layer | Command J |
| Clear selected pixels | Delete |
| Zoom in / out | Command + / Command − |
| Fit canvas to window | Command 0 |
| View at actual size | Command 1 |
| Pan temporarily | Hold Space and drag |

Tool shortcuts apply when you are not typing into a text field.
