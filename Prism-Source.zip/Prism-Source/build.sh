#!/bin/bash
set -euo pipefail
SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"
BUILD_DIR="$SOURCE_DIR/build"
APP_DIR="${1:-$SOURCE_DIR/dist/Prism.app}"
mkdir -p "$BUILD_DIR/module-cache" "$APP_DIR/Contents/MacOS" "$APP_DIR/Contents/Resources/web"
SDK_PATH="$(xcrun --show-sdk-path)"
for ARCH in arm64 x86_64; do
    swiftc "$SOURCE_DIR/native/main.swift" -o "$BUILD_DIR/Prism-$ARCH" -O -swift-version 5 \
      -sdk "$SDK_PATH" -target "$ARCH-apple-macosx12.0" \
      -module-cache-path "$BUILD_DIR/module-cache" -framework AppKit -framework WebKit -framework UniformTypeIdentifiers -framework ImageIO
done
lipo -create "$BUILD_DIR/Prism-arm64" "$BUILD_DIR/Prism-x86_64" -output "$APP_DIR/Contents/MacOS/Prism"
cp "$SOURCE_DIR/native/Info.plist" "$APP_DIR/Contents/Info.plist"
cp "$SOURCE_DIR/web/"*.html "$SOURCE_DIR/web/"*.css "$SOURCE_DIR/web/"*.js "$APP_DIR/Contents/Resources/web/"
if [[ -f "$SOURCE_DIR/assets/Prism.icns" ]]; then cp "$SOURCE_DIR/assets/Prism.icns" "$APP_DIR/Contents/Resources/Prism.icns"; fi
codesign --force --deep --sign - "$APP_DIR"
printf 'Built %s\n' "$APP_DIR"
