# Build verification — 15 October 2026

- Compiled native executable for `arm64` and `x86_64`, targeting macOS 12.0 or later.
- Combined both into a universal Mac application bundle.
- Validated the property list and verified the ad hoc code signature for both architectures.
- Passed 34 functional editor checks using actual Canvas pixels in the bundled offline Skia runtime: drawing, erasing, fill, shapes, layer compositing, opacity, visibility, undo/redo, filters, selection, project round trips, malformed-project rejection, PNG/JPEG export, import, resize, rotate, crop, and zoom.
- Passed 32 interface callback checks with DOM/editor mocks, covering commands, native bridge messages, new/open/save/export paths, replacement cancellation, project identity, and busy-state handling.
- JavaScript syntax checks passed.

## Verification limits

This workspace blocks desktop application launching. The native process could not register with macOS LaunchServices and aborted before `NSApplication` finished constructing. A normal desktop launch, native dialogs, and full WebKit visual verification could not be tested here. No successful end-to-end native launch is claimed.

This build has an ad hoc signature. It is not signed with a Developer ID certificate or notarized by Apple.
