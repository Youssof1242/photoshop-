// Offline fallback: real Canvas pixels with a minimal DOM, no browser or network.
// Supply @napi-rs/canvas through NODE_PATH or PRISM_CANVAS_MODULE.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { createCanvas, Image } = require(process.env.PRISM_CANVAS_MODULE || '@napi-rs/canvas');
let activeEditor;
const wrapper = {
  style: {}, listeners: {},
  appendChild() {},
  addEventListener(type, listener) { (this.listeners[type] ||= []).push(listener); },
  dispatchEvent(event) { for (const listener of this.listeners[event.type] || []) listener(event); },
  getBoundingClientRect() { return {left:47,top:117,width:1100,height:700}; },
  setPointerCapture() {}, releasePointerCapture() {}, hasPointerCapture() { return false; }
};
function canvas() {
  const c = createCanvas(1,1); c.style = {}; c.className=''; c.addEventListener=()=>{};
  c.getBoundingClientRect = () => {
    const r=wrapper.getBoundingClientRect(),w=parseFloat(c.style.width)||c.width,h=parseFloat(c.style.height)||c.height;
    return {left:r.left+(r.width-w)/2+(activeEditor?.panX||0),top:r.top+(r.height-h)/2+(activeEditor?.panY||0),width:w,height:h};
  };
  return c;
}
const document = {createElement(type){if(type==='canvas') return canvas();throw Error('Unexpected element '+type);},addEventListener(){}};
const window = {addEventListener(){},PRISM_ENGINE_ONLY:true};
const context = vm.createContext({window,document,Image,console,atob:s=>Buffer.from(s,'base64').toString('binary'),Uint8Array,Uint8ClampedArray,Float32Array,Math,Number,String,Object,JSON,Date,Set,Map,Promise,Error,Array,RegExp,setTimeout,clearTimeout,navigator:{platform:'offline-'+process.arch},getComputedStyle:()=>({position:'relative'}),ResizeObserver:class{observe(){}},requestAnimationFrame:callback=>setImmediate(callback),PointerEvent:class{constructor(type,options){Object.assign(this,{type,target:{closest:()=>null},preventDefault(){}},options);}}});
vm.runInContext(fs.readFileSync(path.join(__dirname,'../web/editor.js'),'utf8'),context,{filename:'editor.js'});
activeEditor = new window.PrismEditor(canvas(),wrapper);
window.PrismApp = {editor:activeEditor};
(async()=>{
  const test=fs.readFileSync(path.join(__dirname,'editor-test.js'),'utf8');
  const result=await vm.runInContext('(async()=>{'+test+'})()',context,{filename:'editor-test.js'});
  const destination=process.env.PRISM_TEST_RESULT||path.join(__dirname,'engine-test-result.json');
  fs.writeFileSync(destination,JSON.stringify(result,null,2));
  if (process.env.PRISM_ARTWORK) fs.writeFileSync(process.env.PRISM_ARTWORK,Buffer.from(activeEditor.exportImage('png').split(',')[1],'base64'));
  console.log(JSON.stringify(result,null,2));
  process.exitCode=result.passed?0:1;
})();
