const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
let document;
const voidTags=new Set(['input','img','br','hr','meta','link']);
class Element {
  constructor(tag='div',attrs={}){this.tagName=tag.toUpperCase();this.attrs=attrs;this.children=[];this.parentNode=null;this.style={};this.dataset={};this._text='';this._value=attrs.value||'';this.hidden='hidden'in attrs;this.disabled='disabled'in attrs;this.checked='checked'in attrs;this.scrollTop=0;this.className=attrs.class||'';this.id=attrs.id||'';this.title=attrs.title||'';for(const [k,v]of Object.entries(attrs))if(k.startsWith('data-'))this.dataset[k.slice(5).replace(/-([a-z])/g,(_,c)=>c.toUpperCase())]=v;this.classList={add:(...xs)=>this.className=[...new Set([...this.className.split(/\s+/),...xs])].join(' ').trim(),remove:(...xs)=>this.className=this.className.split(/\s+/).filter(x=>!xs.includes(x)).join(' '),toggle:(x,on)=>{let has=this.className.split(/\s+/).includes(x);if(on===undefined)on=!has;if(on)this.classList.add(x);else this.classList.remove(x);return on;},contains:x=>this.className.split(/\s+/).includes(x)};}
  append(...els){for(let el of els){if(typeof el==='string'){this._text+=el;continue;}el.parentNode=this;this.children.push(el);}}
  replaceChildren(...els){this.children=[];this.append(...els);}
  remove(){if(this.parentNode)this.parentNode.children=this.parentNode.children.filter(x=>x!==this);}
  set innerHTML(value){this.children=[];this._text='';parse(String(value),this);}
  get innerHTML(){return this._html||'';}
  set textContent(value){this._text=String(value);this.children=[];}
  get textContent(){return this._text+this.children.map(x=>x.textContent).join('');}
  set value(v){this._value=String(v);}
  get value(){if(this.tagName==='SELECT'&&!this._value)return this.children.find(x=>x.tagName==='OPTION')?.value||'';return this._value;}
  setAttribute(k,v){this.attrs[k]=String(v);if(k==='class')this.className=v;if(k==='id')this.id=v;}
  getAttribute(k){return this.attrs[k];}
  addEventListener(name,fn){(this.listeners||={})[name]||=[];this.listeners[name].push(fn);}
  focus(){document.activeElement=this;}
  select(){}
  getBoundingClientRect(){return{left:100,top:100,bottom:125,right:325,width:225,height:160};}
  get offsetHeight(){return 250;}
  setPointerCapture(){}
  matchesSimple(s){const not=s.match(/:not\(([^)]+)\)/);if(not){if(this.matchesSimple(not[1]))return false;s=s.replace(not[0],'');}const id=s.match(/#([\w-]+)/);if(id&&this.id!==id[1])return false;for(const c of [...s.matchAll(/\.([\w-]+)/g)])if(!this.className.split(/\s+/).includes(c[1]))return false;for(const m of [...s.matchAll(/\[([\w-]+)(?:=["']?([^\]"']+)["']?)?\]/g)]){if(!(m[1]in this.attrs)&&!(m[1].startsWith('data-')&&m[1].slice(5)in this.dataset))return false;const val=m[1].startsWith('data-')?this.dataset[m[1].slice(5)]:this.attrs[m[1]];if(m[2]!==undefined&&String(val)!==m[2])return false;}const tag=s.match(/^[a-zA-Z][\w-]*/)?.[0];if(tag&&this.tagName!==tag.toUpperCase())return false;return true;}
  matches(s){return s.split(',').some(part=>{const chain=part.trim().split(/\s+/);let node=this;if(!node.matchesSimple(chain.pop()))return false;while(chain.length){const p=chain.pop();node=node.parentNode;while(node&&!node.matchesSimple(p))node=node.parentNode;if(!node)return false;}return true;});}
  closest(s){let el=this;while(el){if(el.matches(s))return el;el=el.parentNode;}return null;}
  querySelectorAll(s){let result=[];for(const el of this.children){if(el.matches(s))result.push(el);result.push(...el.querySelectorAll(s));}return result;}
  querySelector(s){return this.querySelectorAll(s)[0]||null;}
  click(){return this.onclick?.({target:this,currentTarget:this,preventDefault(){},stopPropagation(){}});}
}
function parse(html,root){let stack=[root];for(const token of html.match(/<[^>]+>|[^<]+/g)||[]){if(token.startsWith('</')){if(stack.length>1)stack.pop();continue;}if(token.startsWith('<!'))continue;if(token.startsWith('<')){const tag=token.match(/^<([\w-]+)/)?.[1];if(!tag)continue;const attrs={};const raw=token.slice(tag.length+1,-1);for(const m of raw.matchAll(/([\w-]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g))attrs[m[1]]=m[2]??m[3]??m[4]??'';const el=new Element(tag,attrs);stack.at(-1).append(el);if(!voidTags.has(tag)&&!token.endsWith('/>'))stack.push(el);}else stack.at(-1)._text+=token;}}
document=new Element('document');document.body=new Element('body');document.append(document.body);document.createElement=tag=>new Element(tag);document.activeElement=document.body;
const html=fs.readFileSync(path.join(__dirname,'../web/index.html'),'utf8').replace(/<script[\s\S]*?<\/script>/g,'');parse(html,document.body);
const bridgeMessages=[];
class EditorStub{
constructor(){this.events={};this.busy=false;this.s={width:1400,height:980,name:'Demo',layers:[{id:'bottom',name:'Background',visible:true,locked:false,opacity:1,blendMode:'normal',thumbnail:'data:image/png;base64,x',x:0,y:0},{id:'top',name:'Mountains',visible:true,locked:false,opacity:1,blendMode:'normal',thumbnail:'data:image/png;base64,x',x:0,y:0}],selectedLayerId:'top',tool:'move',color:'#202b36',secondaryColor:'#ffffff',brushSize:32,brushOpacity:1,zoom:.5,dirty:false,history:[{name:'Original'}],historyIndex:0,busy:false};}
on(n,f){(this.events[n]||=[]).push(f);}
change(){this.s.busy=this.busy;for(const fn of this.events.change||[])fn(this.getState());}
getState(){return JSON.parse(JSON.stringify(this.s));}
exportImage(type='png'){return 'data:image/'+type+';base64,TEST';}
newDocument(w,h,name){this.s.width=w;this.s.height=h;this.s.name=name;this.s.dirty=false;this.newCount=(this.newCount||0)+1;this.change();}
async loadImage(dataURL,name){this.s.name=name;this.s.dirty=false;this.loadCount=(this.loadCount||0)+1;this.change();}
async addImage(dataURL,name){this.s.dirty=true;this.placeCount=(this.placeCount||0)+1;this.change();}
async loadProject(json){this.s.name=JSON.parse(json).name;this.s.dirty=false;this.projectCount=(this.projectCount||0)+1;this.change();}
serializeProject(){return JSON.stringify(this.s);}
markSaved(){this.s.dirty=false;this.change();}
setTool(v){this.s.tool=v;this.change();}
setColor(v){this.s.color=v;this.change();}
setSecondaryColor(v){this.s.secondaryColor=v;this.change();}
setBrushSize(v){this.s.brushSize=v;this.change();}
setBrushOpacity(v){this.s.brushOpacity=v;this.change();}
setZoom(v){this.s.zoom=v;this.change();}
fitToView(){this.s.zoom=.4;this.change();}
selectLayer(id){this.s.selectedLayerId=id;this.change();}
updateLayer(id,props){Object.assign(this.s.layers.find(l=>l.id===id),props);this.s.dirty=true;this.change();}
addLayer(){this.s.layers.push({id:'new',name:'Layer3',visible:true,locked:false,opacity:1,blendMode:'normal',thumbnail:'data:image/png;base64,x'});this.s.selectedLayerId='new';this.s.dirty=true;this.change();}
async goToHistory(i){this.s.historyIndex=i;this.change();}
async undo(){this.s.historyIndex=Math.max(0,this.s.historyIndex-1);this.change();}
async redo(){this.s.historyIndex=Math.min(this.s.history.length-1,this.s.historyIndex+1);this.change();}
}
const window={PrismEditor:EditorStub,webkit:{messageHandlers:{prism:{postMessage:m=>bridgeMessages.push(m)}}}};const timeouts=[];
const sandbox={window,document,console,innerWidth:1300,innerHeight:800,navigator:{},requestAnimationFrame:f=>{f();},setTimeout:f=>timeouts.push(f),clearTimeout(){},Blob,URL,FileReader:function(){},File:function(){},ClipboardItem:function(){},fetch:async()=>({blob:async()=>new Blob()})};
vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../web/ui.js'),'utf8'),sandbox,{filename:'ui.js'});
const app=window.PrismApp,editor=app.editor,$=s=>document.querySelector(s),$$=s=>document.querySelectorAll(s);
let checks=0;function check(value,message){assert(value,message);checks++;}
(async()=>{
check(app&&editor,'App initialized');check($$('.tool-button').length===12,'12 tools');check($$('.menu-trigger').length===8,'8 menus');check($$('.layer-row')[0].dataset.id==='top','Layers reversed');check($('#blendMode').value==='normal','Normal blend option');check(bridgeMessages.at(-1).action==='ready','Native ready');
await app.command('new');check($('.modal')!==null,'New modal');$('#newWidth').value='800';$('#newHeight').value='600';$('#newName').value='New canvas';await $('.modal-button.primary').click();check(editor.s.name==='New canvas'&&editor.s.width===800,'New action creates document');check(bridgeMessages.some(m=>m.action==='documentReplaced'),'New resets project identity');
editor.s.dirty=true;editor.change();const before=bridgeMessages.filter(m=>m.action==='documentReplaced').length;const opening=app.receiveFile({name:'Cancel.png',dataURL:'data:x'});check($('#modalTitle').textContent==='Keep your changes?','Incoming open requests confirmation');await $$('.modal-button')[0].click();check(await opening===false,'Cancelled receive returns false');check(!editor.loadCount,'Cancelled receive does not load');check(bridgeMessages.filter(m=>m.action==='documentReplaced').length===before,'Cancelled receive preserves native URL');
const accepted=app.receiveFile({name:'Accepted.png',dataURL:'data:x'});await $('.modal-button.primary').click();check(await accepted===true,'Accepted receive returns true');check(editor.s.name==='Accepted.png','Accepted receive opens image');check(bridgeMessages.filter(m=>m.action==='documentReplaced').length===before+1,'Accepted receive resets URL');
const placed=await app.receiveFile({name:'Placed.png',dataURL:'data:x',place:true});check(placed===true&&editor.placeCount===1,'Native place adds image');check(bridgeMessages.filter(m=>m.action==='documentReplaced').length===before+1,'Native place preserves URL');
editor.s.dirty=false;editor.change();check(await app.receiveProject({name:'Design.prism',json:'{"name":"Design"}'})===true,'Project returns true');check(editor.s.name==='Design'&&!editor.s.dirty,'Project clean');
await app.command('export');check($('#exportFormat').value==='png','Export defaults PNG');$('#exportName').value='Final';await $('.modal-button.primary').click();check(bridgeMessages.at(-1).action==='export'&&bridgeMessages.at(-1).name==='Final.png','PNG export bridge');
check(await app.command('save')===true,'Save command returns true');check(bridgeMessages.at(-1).action==='saveProject','Save project bridge');check(await app.command('saveAs')===true&&bridgeMessages.at(-1).saveAs===true,'Save As force flag');
editor.busy=true;editor.change();check(await app.command('save')===false,'Busy save rejected');check(await app.receiveFile({name:'Busy.png',dataURL:'data:x'})===false,'Busy receive rejected');check(bridgeMessages.filter(m=>m.action==='state').at(-1).busy===true,'Busy native state');editor.busy=false;editor.change();
await app.command('help');check($$('.shortcut-row').length===16,'Help shortcuts populated');await $('.modal-button.primary').click();await app.command('showHistory');check(!$('#historyView').hidden&&$('#layersView').hidden,'History panel works');await app.command('showLayers');check(!$('#layersView').hidden,'Layers panel works');check(await app.command('unknown')===false,'Unknown command rejected');
console.log(`PASS: ${checks} UI callback and native bridge checks`);
})().catch(e=>{console.error(e);process.exitCode=1;});
