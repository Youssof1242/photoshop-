// Executed inside the shipped application by WebKit, using its real canvas renderer.
const editor = window.PrismApp?.editor || window.prismEditor || window.editor;
if (!editor) return { passed: false, error: 'Editor is not accessible for verification.' };
const checks = [];
function check(name, condition, detail) { checks.push({name, passed: !!condition, ...(detail ? {detail} : {})}); if (!condition) throw new Error(name + (detail ? ': ' + detail : '')); }
function pixel(x, y) { editor.render(); return Array.from(editor.canvas.getContext('2d').getImageData(x,y,1,1).data); }
function isColor(x,y,r,g,b) { const p=pixel(x,y); return Math.abs(p[0]-r)<5 && Math.abs(p[1]-g)<5 && Math.abs(p[2]-b)<5; }
function gesture(tool, x1,y1,x2,y2) {
  editor.setTool(tool);
  const r=editor.canvas.getBoundingClientRect(), w=editor.wrapper;
  const event=(type,x,y)=>w.dispatchEvent(new PointerEvent(type,{bubbles:true,cancelable:true,pointerId:7,pointerType:'mouse',button:0,buttons:type==='pointerup'?0:1,clientX:r.left+x*editor.zoom,clientY:r.top+y*editor.zoom}));
  event('pointerdown',x1,y1); event('pointermove',x2,y2); event('pointerup',x2,y2);
}
const original = editor.serializeProject();
try {
  check('Bundled editor starts with artwork and editable layers', editor.width>0 && editor.layers.length>=3);
  editor.newDocument(128,96,'Release check');
  check('New document dimensions', editor.width===128 && editor.height===96);
  check('New canvas is white', isColor(10,10,255,255,255));
  const background=editor.selectedLayerId;
  editor.setColor('#f02030'); editor.setBrushOpacity(1);
  gesture('rectangle',10,10,50,40);
  check('Rectangle creates a separate layer',editor.layers.length===2);
  check('Rectangle paints document pixels',isColor(20,20,240,32,48));
  const shape=editor.selectedLayerId;
  editor.updateLayer(shape,{visible:false});
  check('Layer visibility affects composite',isColor(20,20,255,255,255));
  editor.updateLayer(shape,{visible:true,opacity:.5,blendMode:'normal'});
  const half=pixel(20,20); check('Layer opacity blends pixels',half[0]>=246&&half[1]>=140&&half[1]<=146);
  editor.updateLayer(shape,{opacity:1});
  editor.duplicateLayer(); check('Duplicate creates independent layer',editor.layers.length===3 && editor.selectedLayerId!==shape);
  editor.deleteLayer(); check('Delete layer',editor.layers.length===2);
  await editor.undo(); check('Undo restores deleted layer',editor.layers.length===3);
  await editor.redo(); check('Redo restores delete',editor.layers.length===2);
  editor.selectLayer(shape); editor.applyFilter('invert');
  check('Invert changes selected layer pixels',isColor(20,20,15,223,207));
  await editor.undo(); check('Undo restores pixel content',isColor(20,20,240,32,48));
  gesture('marquee',10,10,30,30); editor.deleteSelected();
  check('Marquee limits deleted region',isColor(20,20,255,255,255)&&isColor(40,20,240,32,48));
  await editor.undo(); editor.clearSelection();
  editor.addLayer('Paint'); editor.setColor('#2050ff'); editor.setBrushSize(12); editor.setBrushHardness(1);
  gesture('brush',60,50,95,50);
  check('Brush draws a continuous stroke',isColor(70,50,32,80,255)&&isColor(90,50,32,80,255));
  gesture('eraser',70,50,85,50);
  check('Eraser removes pixels on active layer',isColor(76,50,255,255,255));
  editor.addLayer('Fill'); editor.setColor('#32b880'); gesture('fill',4,4,4,4);
  check('Bucket fills connected transparent area',isColor(100,80,50,184,128));
  editor.updateLayer(editor.selectedLayerId,{visible:false});
  editor.setColor('#bb6600'); gesture('ellipse',65,65,95,85);
  check('Ellipse paints center',isColor(80,75,187,102,0));
  const countBeforeText=editor.layers.length;
  editor.addText('P',{size:24,x:4,y:60,color:'#000000'});
  check('Text produces editable layer',editor.layers.length===countBeforeText+1);
  const project=editor.serializeProject(), snapshot=JSON.parse(project);
  check('Project stores all layer pixels',snapshot.format==='prism-project'&&snapshot.layers.length===editor.layers.length&&snapshot.layers.every(l=>l.data.startsWith('data:image/png')));
  editor.newDocument(20,20,'Other'); await editor.loadProject(project);
  check('Project round trip preserves dimensions and layers',editor.width===128&&editor.height===96&&editor.layers.length===snapshot.layers.length);
  check('Project round trip preserves appearance',isColor(80,75,187,102,0));
  let rejected=false; try { await editor.loadProject('{broken'); } catch { rejected=true; }
  check('Malformed project rejected without replacing document',rejected&&editor.width===128);
  rejected=false;try { const invalid=JSON.parse(project);invalid.layers[0].data='https://example.com/image.png';await editor.loadProject(invalid); } catch { rejected=true; }
  check('External image references rejected',rejected&&editor.width===128);
  editor.flatten();check('Flatten composites layers',editor.layers.length===1&&isColor(80,75,187,102,0));
  const png=editor.exportImage('png'), jpg=editor.exportImage('jpeg',.9);
  check('PNG and JPEG export encoded images',png.startsWith('data:image/png;base64,')&&jpg.startsWith('data:image/jpeg;base64,'));
  await editor.loadImage(png,'Round trip.png');check('Image import round trip',editor.width===128&&editor.height===96&&isColor(80,75,187,102,0));
  editor.rotateDocument(90);check('Rotate swaps document dimensions',editor.width===96&&editor.height===128);
  editor.flipDocument('horizontal');check('Flip remains valid',editor.canvas.width===96&&editor.canvas.height===128);
  editor.resizeDocument(192,256);check('Image resize changes pixel dimensions',editor.width===192&&editor.height===256);
  gesture('crop',20,30,120,180);check('Crop applies selected dimensions',editor.width===100&&editor.height===150);
  await editor.undo();check('Undo restores pre-crop size',editor.width===192&&editor.height===256);
  editor.setZoom(.75);check('Zoom sets view scale without changing pixels',editor.zoom===.75&&editor.width===192);
  editor.markSaved();check('Saved state clears unsaved indicator',editor.getState().dirty===false);
  await editor.loadProject(original);editor.fitToView();editor.setTool('move');editor.markSaved();
  await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
  if (!window.PRISM_ENGINE_ONLY) {
    check('UI renders layer stack and document title',document.querySelectorAll('.layer-row').length===editor.layers.length && document.getElementById('documentName').textContent.length>0);
    check('No initial modal blocks editing',!document.querySelector('.modal-backdrop'));
  }
  return {passed:checks.every(c=>c.passed),checks,total:checks.length,engine:window.PRISM_ENGINE_ONLY?'Offline Canvas engine (Skia)':'macOS WKWebView',platform:navigator.platform};
} catch(error) {
  try { await editor.loadProject(original);editor.fitToView();editor.markSaved(); } catch(_){}
  return {passed:false,checks,error:error.message,stack:error.stack};
}
